"""
Hand Gesture Control System
============================
Controls system actions via webcam hand gestures using MediaPipe + OpenCV.

GESTURES:
  ✊ Fist            → Volume Down / Custom Action A
  🖐 Open Hand       → Volume Up / Custom Action B
  ☝ Index Finger    → Move Mouse Cursor
  ✌ Peace Sign       → Left Click
  👌 OK Sign         → Right Click
  🤏 Pinch           → Scroll (move up/down while pinching)
  👆 Thumb Up        → Next Track / Custom Action C
  👇 Thumb Down      → Previous Track / Custom Action D
  🖕 Middle Finger   → Screenshot
"""

import cv2
import mediapipe as mp
import numpy as np
import pyautogui
import time
import math
import sys
import os

# ──────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────
CAMERA_INDEX        = 0
FRAME_W, FRAME_H    = 1280, 720
GESTURE_COOLDOWN    = 0.6       # seconds between gesture triggers
CURSOR_SMOOTHING    = 0.15      # lower = smoother / more lag
PINCH_THRESHOLD     = 0.055     # normalised distance for pinch
CLICK_THRESHOLD     = 0.045
SCROLL_SENSITIVITY  = 8         # pixels per frame while pinching

pyautogui.FAILSAFE = False       # disable corner-escape

# ──────────────────────────────────────────────────────────────
# MEDIAPIPE SETUP
# ──────────────────────────────────────────────────────────────
mp_hands    = mp.solutions.hands
mp_drawing  = mp.solutions.drawing_utils
mp_styles   = mp.solutions.drawing_styles

SCREEN_W, SCREEN_H = pyautogui.size()

# ──────────────────────────────────────────────────────────────
# LANDMARK INDICES  (MediaPipe Hand)
# ──────────────────────────────────────────────────────────────
WRIST           = 0
THUMB_CMC       = 1;  THUMB_MCP   = 2;  THUMB_IP    = 3;  THUMB_TIP   = 4
INDEX_MCP       = 5;  INDEX_PIP   = 6;  INDEX_DIP   = 7;  INDEX_TIP   = 8
MIDDLE_MCP      = 9;  MIDDLE_PIP  = 10; MIDDLE_DIP  = 11; MIDDLE_TIP  = 12
RING_MCP        = 13; RING_PIP    = 14; RING_DIP    = 15; RING_TIP    = 16
PINKY_MCP       = 17; PINKY_PIP   = 18; PINKY_DIP   = 19; PINKY_TIP   = 20


# ──────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ──────────────────────────────────────────────────────────────

def lm_to_np(lms, w, h):
    """Return (N, 3) pixel array from landmark list."""
    return np.array([[lm.x * w, lm.y * h, lm.z] for lm in lms.landmark])


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def norm_dist(pts, i, j, ref_len):
    """Normalised distance between two landmarks."""
    return dist(pts[i], pts[j]) / (ref_len + 1e-6)


def finger_extended(pts, tip, pip, mcp, wrist, threshold=0.12):
    """True when fingertip is farther from wrist than PIP joint."""
    return dist(pts[tip], pts[wrist]) > dist(pts[pip], pts[wrist]) * 1.15


def thumb_extended(pts, wrist):
    return dist(pts[THUMB_TIP], pts[WRIST]) > dist(pts[THUMB_IP], pts[WRIST]) * 1.1


# ──────────────────────────────────────────────────────────────
# GESTURE CLASSIFIER
# ──────────────────────────────────────────────────────────────

def classify_gesture(pts, w, h):
    """
    Returns (gesture_name, extra_data_dict)
    """
    ref = dist(pts[WRIST], pts[MIDDLE_MCP])   # palm size reference

    index_up  = finger_extended(pts, INDEX_TIP,  INDEX_PIP,  INDEX_MCP,  WRIST)
    middle_up = finger_extended(pts, MIDDLE_TIP, MIDDLE_PIP, MIDDLE_MCP, WRIST)
    ring_up   = finger_extended(pts, RING_TIP,   RING_PIP,   RING_MCP,   WRIST)
    pinky_up  = finger_extended(pts, PINKY_TIP,  PINKY_PIP,  PINKY_MCP,  WRIST)
    thumb_up  = thumb_extended(pts, WRIST)

    fingers_up = [index_up, middle_up, ring_up, pinky_up]
    count_up   = sum(fingers_up)

    # Pinch (thumb ↔ index close)
    pinch_dist = norm_dist(pts, THUMB_TIP, INDEX_TIP, ref)
    is_pinch   = pinch_dist < PINCH_THRESHOLD

    # ── Specific gestures (order matters) ──

    # 1. OPEN HAND  – all 4 fingers + thumb up
    if count_up == 4 and thumb_up:
        return "open_hand", {}

    # 2. FIST – no fingers up
    if count_up == 0 and not thumb_up:
        return "fist", {}

    # 3. PEACE / V-sign – index + middle, others down
    if index_up and middle_up and not ring_up and not pinky_up:
        return "peace", {}

    # 4. POINTING (index only)
    if index_up and not middle_up and not ring_up and not pinky_up:
        tip = pts[INDEX_TIP]
        nx  = np.interp(tip[0], [0, w], [0, SCREEN_W])
        ny  = np.interp(tip[1], [0, h], [0, SCREEN_H])
        return "pointing", {"x": nx, "y": ny}

    # 5. THREE FINGERS – index + middle + ring
    if index_up and middle_up and ring_up and not pinky_up:
        return "three_fingers", {}

    # 6. OK SIGN – index+thumb pinch, others curled
    if is_pinch and not middle_up and not ring_up and not pinky_up:
        return "ok", {}

    # 7. PINCH SCROLL – thumb+index pinch, middle up (to distinguish from OK)
    if is_pinch and middle_up:
        return "pinch_scroll", {"pinch_dist": pinch_dist}

    # 8. THUMB UP – only thumb extended, fingers curled, thumb points up
    if thumb_up and count_up == 0:
        thumb_vec = pts[THUMB_TIP][1] - pts[THUMB_CMC][1]   # negative = up
        if thumb_vec < 0:
            return "thumb_up", {}
        else:
            return "thumb_down", {}

    # 9. MIDDLE FINGER – only middle up
    if not index_up and middle_up and not ring_up and not pinky_up:
        return "middle_finger", {}

    # 10. CALL ME – thumb + pinky up
    if thumb_up and pinky_up and not index_up and not middle_up and not ring_up:
        return "call_me", {}

    return "unknown", {}


# ──────────────────────────────────────────────────────────────
# ACTION EXECUTOR
# ──────────────────────────────────────────────────────────────

class GestureController:
    def __init__(self):
        self.last_gesture      = None
        self.last_trigger_time = 0
        self.smooth_x          = SCREEN_W  // 2
        self.smooth_y          = SCREEN_H  // 2
        self.prev_pinch_y      = None
        self.gesture_log       = []          # rolling history for display
        self.action_counts     = {}          # stats

    def cooldown_ok(self):
        return (time.time() - self.last_trigger_time) > GESTURE_COOLDOWN

    def log(self, msg):
        ts = time.strftime("%H:%M:%S")
        entry = f"[{ts}] {msg}"
        self.gesture_log.append(entry)
        if len(self.gesture_log) > 8:
            self.gesture_log.pop(0)
        print(entry)

    def execute(self, gesture, data):
        now = time.time()

        # ── CONTINUOUS GESTURES (no cooldown) ──

        if gesture == "pointing":
            tx, ty = data["x"], data["y"]
            self.smooth_x += (tx - self.smooth_x) * CURSOR_SMOOTHING
            self.smooth_y += (ty - self.smooth_y) * CURSOR_SMOOTHING
            pyautogui.moveTo(int(self.smooth_x), int(self.smooth_y))
            return gesture   # don't spam log

        if gesture == "pinch_scroll":
            # Use current wrist Y for scroll direction
            return gesture

        # ── DISCRETE GESTURES (with cooldown) ──
        if not self.cooldown_ok():
            return self.last_gesture

        self.last_trigger_time = now
        self.last_gesture = gesture
        self.action_counts[gesture] = self.action_counts.get(gesture, 0) + 1

        if gesture == "open_hand":
            pyautogui.press("volumeup")
            self.log("🖐  Open Hand → Volume UP")

        elif gesture == "fist":
            pyautogui.press("volumedown")
            self.log("✊  Fist → Volume DOWN")

        elif gesture == "peace":
            pyautogui.click()
            self.log("✌  Peace → Left Click")

        elif gesture == "ok":
            pyautogui.rightClick()
            self.log("👌  OK → Right Click")

        elif gesture == "three_fingers":
            pyautogui.hotkey("alt", "tab")
            self.log("🤟  Three Fingers → Alt+Tab")

        elif gesture == "thumb_up":
            pyautogui.press("nexttrack")
            self.log("👍  Thumb Up → Next Track")

        elif gesture == "thumb_down":
            pyautogui.press("prevtrack")
            self.log("👎  Thumb Down → Previous Track")

        elif gesture == "middle_finger":
            path = os.path.expanduser(f"~/screenshot_{int(now)}.png")
            pyautogui.screenshot(path)
            self.log(f"📸  Middle Finger → Screenshot → {path}")

        elif gesture == "call_me":
            pyautogui.hotkey("super", "d")   # show desktop
            self.log("🤙  Call Me → Show Desktop")

        return gesture


# ──────────────────────────────────────────────────────────────
# OVERLAY DRAWING
# ──────────────────────────────────────────────────────────────

GESTURE_ICONS = {
    "open_hand":     ("🖐  OPEN HAND",   (0, 220, 120)),
    "fist":          ("✊  FIST",         (0, 100, 255)),
    "peace":         ("✌  PEACE",        (255, 200, 0)),
    "pointing":      ("☝  POINTING",     (200, 200, 200)),
    "ok":            ("👌  OK",           (0, 255, 200)),
    "pinch_scroll":  ("🤏  PINCH SCROLL",(150, 100, 255)),
    "three_fingers": ("🤟  THREE",        (255, 140, 0)),
    "thumb_up":      ("👍  THUMB UP",    (50, 255, 50)),
    "thumb_down":    ("👎  THUMB DOWN",  (50, 50, 255)),
    "middle_finger": ("🖕  SCREENSHOT",  (255, 50, 50)),
    "call_me":       ("🤙  CALL ME",     (200, 50, 255)),
    "unknown":       ("❓  UNKNOWN",     (100, 100, 100)),
}

def draw_overlay(frame, gesture, controller, fps):
    h, w = frame.shape[:2]

    # Semi-transparent sidebar
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (340, h), (10, 10, 20), -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)

    # Title
    cv2.putText(frame, "HAND GESTURE CONTROL", (12, 34),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (180, 255, 220), 2)
    cv2.line(frame, (12, 42), (328, 42), (60, 80, 60), 1)

    # FPS
    cv2.putText(frame, f"FPS: {fps:.0f}", (12, 64),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (160, 160, 160), 1)

    # Current gesture badge
    icon, color = GESTURE_ICONS.get(gesture, ("❓ UNKNOWN", (100,100,100)))
    cv2.rectangle(frame, (12, 76), (328, 116), (*color[::-1], 255), -1)
    cv2.rectangle(frame, (12, 76), (328, 116), (255,255,255), 1)
    cv2.putText(frame, icon[:20], (20, 104),
                cv2.FONT_HERSHEY_DUPLEX, 0.65, (0, 0, 0), 2)

    # Gesture reference card
    y0 = 130
    cv2.putText(frame, "GESTURE MAP", (12, y0),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (120, 180, 255), 1)
    y0 += 6
    for g, (lbl, col) in GESTURE_ICONS.items():
        if g in ("unknown", "pointing"): continue
        y0 += 18
        dot_color = col
        cv2.circle(frame, (18, y0 - 4), 4, dot_color, -1)
        cv2.putText(frame, lbl[:28], (28, y0),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.35, (220, 220, 220), 1)

    # Activity log
    y0 += 28
    cv2.line(frame, (12, y0), (328, y0), (60,80,60), 1)
    y0 += 14
    cv2.putText(frame, "ACTIVITY LOG", (12, y0),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, (120, 180, 255), 1)
    for entry in controller.gesture_log[-5:]:
        y0 += 15
        cv2.putText(frame, entry[-38:], (12, y0),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.30, (190, 190, 190), 1)

    # Quit hint
    cv2.putText(frame, "Press Q to quit", (12, h - 12),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, (100,100,100), 1)

    return frame


# ──────────────────────────────────────────────────────────────
# MAIN LOOP
# ──────────────────────────────────────────────────────────────

def main():
    cap = cv2.VideoCapture(CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  FRAME_W)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_H)
    cap.set(cv2.CAP_PROP_FPS, 60)

    controller = GestureController()
    prev_time  = time.time()
    current_gesture = "unknown"

    with mp_hands.Hands(
        model_complexity        = 1,
        max_num_hands           = 1,
        min_detection_confidence= 0.70,
        min_tracking_confidence = 0.60,
    ) as hands:

        print("\n╔══════════════════════════════════════╗")
        print("║   HAND GESTURE CONTROL — READY       ║")
        print("╠══════════════════════════════════════╣")
        print("║  Open Hand  → Volume Up              ║")
        print("║  Fist       → Volume Down            ║")
        print("║  Index Up   → Move Cursor            ║")
        print("║  Peace ✌   → Left Click              ║")
        print("║  OK 👌      → Right Click            ║")
        print("║  Pinch+Mid  → Scroll                 ║")
        print("║  Thumb Up   → Next Track             ║")
        print("║  Thumb Down → Prev Track             ║")
        print("║  Middle 🖕  → Screenshot             ║")
        print("║  Call Me 🤙 → Show Desktop           ║")
        print("╠══════════════════════════════════════╣")
        print("║  Press Q in window to exit           ║")
        print("╚══════════════════════════════════════╝\n")

        while True:
            ok, frame = cap.read()
            if not ok:
                print("[ERROR] Camera read failed.")
                break

            frame = cv2.flip(frame, 1)
            rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w  = frame.shape[:2]

            results = hands.process(rgb)

            gesture = "unknown"
            extra   = {}

            if results.multi_hand_landmarks:
                for hand_lms in results.multi_hand_landmarks:
                    # Draw skeleton
                    mp_drawing.draw_landmarks(
                        frame, hand_lms,
                        mp_hands.HAND_CONNECTIONS,
                        mp_styles.get_default_hand_landmarks_style(),
                        mp_styles.get_default_hand_connections_style(),
                    )

                    pts     = lm_to_np(hand_lms, w, h)
                    gesture, extra = classify_gesture(pts, w, h)

                    # Pinch scroll – use fingertip Y movement
                    if gesture == "pinch_scroll":
                        tip_y = pts[INDEX_TIP][1]
                        if controller.prev_pinch_y is not None:
                            delta = tip_y - controller.prev_pinch_y
                            pyautogui.scroll(-int(delta * SCROLL_SENSITIVITY))
                        controller.prev_pinch_y = tip_y
                    else:
                        controller.prev_pinch_y = None

                    current_gesture = controller.execute(gesture, extra)
                    break   # only process first hand

            else:
                current_gesture = "unknown"
                controller.prev_pinch_y = None

            # FPS
            now  = time.time()
            fps  = 1.0 / max(now - prev_time, 1e-6)
            prev_time = now

            frame = draw_overlay(frame, current_gesture, controller, fps)

            cv2.imshow("Hand Gesture Control", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                print("\n[INFO] Quit requested. Goodbye!")
                break

    cap.release()
    cv2.destroyAllWindows()

    print("\n── SESSION STATS ──")
    for g, cnt in sorted(controller.action_counts.items(), key=lambda x: -x[1]):
        print(f"  {g:20s}: {cnt}×")


if __name__ == "__main__":
    main()
