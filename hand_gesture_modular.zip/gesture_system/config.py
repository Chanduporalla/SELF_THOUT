# config.py
# ══════════════════════════════════════════════════════════════
# Central configuration — edit this file to tune the system.
# ══════════════════════════════════════════════════════════════

import os
import pyautogui

# ── Camera ────────────────────────────────────────────────────
CAMERA_INDEX  = 0       # 0 = default webcam, 1 = second camera
FRAME_W       = 1280
FRAME_H       = 720
CAMERA_FPS    = 60

# ── Detection ─────────────────────────────────────────────────
MAX_HANDS              = 1
MIN_DETECTION_CONF     = 0.72
MIN_TRACKING_CONF      = 0.62
MODEL_COMPLEXITY       = 1

# ── Gesture feel ──────────────────────────────────────────────
GESTURE_COOLDOWN   = 0.65   # seconds between discrete triggers
CURSOR_SMOOTHING   = 0.18   # 0 = frozen, 1 = instant (0.1–0.2 = natural)
PINCH_THRESHOLD    = 0.055  # lower = harder to trigger pinch
SCROLL_SENSITIVITY = 12     # scroll units per frame

# ── System ────────────────────────────────────────────────────
VOLUME_STEP      = 5        # percent per volume gesture
SCREENSHOT_DIR   = os.path.expanduser("~/Pictures/gestures")

# ── Screen (auto-detected) ────────────────────────────────────
SCREEN_W, SCREEN_H = pyautogui.size()

# ── Modes ─────────────────────────────────────────────────────
# Available modes: "system" | "vscode" | "sublime"
DEFAULT_MODE = "system"

# ── IDE detection (auto-switch) ───────────────────────────────
# If True, the system watches the active window and switches
# mode automatically when VS Code or Sublime Text is focused.
AUTO_SWITCH_IDE_MODE = True

VSCODE_WINDOW_TITLES  = ["visual studio code", "vscode", "code"]
SUBLIME_WINDOW_TITLES = ["sublime text", "sublime_text"]
