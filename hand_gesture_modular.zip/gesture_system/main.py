#!/usr/bin/env python3
"""
Hand Gesture Control System
============================
Entry point. Reads config, runs the camera loop, dispatches
gestures to the active mode controller.

Usage:
  python3 main.py                  # default mode (system)
  python3 main.py --mode vscode    # start in VS Code mode
  python3 main.py --mode sublime   # start in Sublime mode
  python3 main.py --no-auto        # disable auto IDE mode switching
"""

import cv2
import time
import argparse
import os
import sys

# Make sure the project root is on the path
sys.path.insert(0, os.path.dirname(__file__))

import config
from core.camera     import Camera
from core.detector   import HandDetector
from core.classifier import classify
from ui.overlay      import draw

from modes.system_mode  import SystemMode
from modes.vscode_mode  import VSCodeMode
from modes.sublime_mode import SublimeMode

from actions import volume, screenshot, window
from actions.mouse import hotkey, press


# ──────────────────────────────────────────────────────────────
# MODE REGISTRY
# ──────────────────────────────────────────────────────────────

MODES = {
    "system":  SystemMode,
    "vscode":  VSCodeMode,
    "sublime": SublimeMode,
}

MODE_ORDER = ["system", "vscode", "sublime"]   # cycle with TAB key


# ──────────────────────────────────────────────────────────────
# AUTO MODE DETECTION
# ──────────────────────────────────────────────────────────────

def detect_mode_from_window():
    """
    Check the active window title and return the best mode name,
    or None if no IDE match.
    """
    title = window.get_active_window_title()
    if not title:
        return None
    for kw in config.VSCODE_WINDOW_TITLES:
        if kw in title:
            return "vscode"
    for kw in config.SUBLIME_WINDOW_TITLES:
        if kw in title:
            return "sublime"
    return "system"


# ──────────────────────────────────────────────────────────────
# DIAGNOSTICS
# ──────────────────────────────────────────────────────────────

def print_startup(auto_switch):
    import shutil, platform
    tools = [
        ("pactl",         "Volume"),
        ("playerctl",     "Media"),
        ("scrot",         "Screenshots"),
        ("xdotool",       "Keys/Windows"),
        ("wmctrl",        "Window mgmt"),
        ("brightnessctl", "Brightness"),
        ("xclip",         "Clipboard"),
    ]
    print("\n╔══════════════════════════════════════════════════╗")
    print("║   HAND GESTURE CONTROL  —  Modular Edition      ║")
    print("╠══════════════════════════════════════════════════╣")
    print(f"║  OS      : {platform.system()} {platform.release()[:20]:<25}║")
    print(f"║  Screen  : {config.SCREEN_W}x{config.SCREEN_H:<33}║")
    print(f"║  Camera  : {config.CAMERA_INDEX:<38}║")
    print(f"║  Auto-IDE: {'YES (window watching)' if auto_switch else 'NO (manual TAB)':<38}║")
    print("╠══════════════════════════════════════════════════╣")
    print("║  TOOL           STATUS  FUNCTION                 ║")
    for tool, fn in tools:
        ok = "  OK  " if shutil.which(tool) else " MISS "
        print(f"║  {tool:<16} [{ok}] {fn:<24}║")
    print("╠══════════════════════════════════════════════════╣")
    print("║  KEYBOARD (camera window focused):               ║")
    print("║  TAB = cycle mode    M = mute    S = screenshot  ║")
    print("║  B/V = bright+/-     P = play    H = minimize    ║")
    print("║  W = close win   X = maximize   L = lock screen  ║")
    print("║  Q = quit                                        ║")
    print("╚══════════════════════════════════════════════════╝\n")


# ──────────────────────────────────────────────────────────────
# MAIN LOOP
# ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Hand Gesture Control")
    parser.add_argument("--mode",    default=config.DEFAULT_MODE,
                        choices=MODES.keys())
    parser.add_argument("--no-auto", action="store_true",
                        help="Disable automatic IDE mode switching")
    args = parser.parse_args()

    auto_switch = config.AUTO_SWITCH_IDE_MODE and not args.no_auto
    print_startup(auto_switch)

    os.makedirs(config.SCREENSHOT_DIR, exist_ok=True)

    # ── Initialise controllers (one per mode, preserves log/stats) ──
    controllers = {name: cls() for name, cls in MODES.items()}
    current_mode = args.mode

    # ── Open camera & detector ──
    try:
        cam = Camera().open()
    except RuntimeError as e:
        print(f"[ERROR] {e}")
        return

    detector  = HandDetector().start()
    prev_time = time.time()
    cur_g     = "unknown"
    vol_cache = None
    vol_timer = 0.0

    # Auto-switch polling interval
    last_window_check = 0.0
    WINDOW_CHECK_INTERVAL = 1.2   # seconds

    try:
        while True:
            frame, rgb = cam.read()
            if frame is None:
                print("[ERROR] Camera read failed.")
                break

            h, w = frame.shape[:2]
            ctrl = controllers[current_mode]
            ctrl.set_frame(frame.copy())

            # ── Auto mode switch ──────────────────────────────
            if auto_switch and (time.time() - last_window_check) > WINDOW_CHECK_INTERVAL:
                detected = detect_mode_from_window()
                if detected and detected != current_mode:
                    current_mode = detected
                    ctrl = controllers[current_mode]
                    ctrl.log(f"[AUTO] Switched to {current_mode} mode")
                last_window_check = time.time()

            # ── Hand detection + gesture classification ───────
            landmarks, frame = detector.process_and_draw(frame, rgb)

            gesture, extra = "unknown", {}
            if landmarks:
                pts = landmarks[0]   # first hand only
                gesture, extra = classify(pts, w, h)

            cur_g = ctrl.execute(gesture, extra)

            # ── Volume polling (refresh every 2 s) ────────────
            if time.time() - vol_timer > 2.0:
                vol_cache = volume.get_volume()
                vol_timer = time.time()

            # ── FPS ───────────────────────────────────────────
            now = time.time()
            fps = 1.0 / max(now - prev_time, 1e-6)
            prev_time = now

            # ── Draw overlay ──────────────────────────────────
            frame = draw(frame, cur_g, current_mode, ctrl, fps, vol_cache)
            cv2.imshow("Hand Gesture Control", frame)

            # ── Keyboard shortcuts ────────────────────────────
            key = cv2.waitKey(1) & 0xFF

            if key == ord("q"):
                print("\n[INFO] Quit.")
                break

            elif key == 9:   # TAB — cycle mode manually
                idx = (MODE_ORDER.index(current_mode) + 1) % len(MODE_ORDER)
                current_mode = MODE_ORDER[idx]
                ctrl = controllers[current_mode]
                ctrl.log(f"[MANUAL] Switched to {current_mode} mode")

            elif key == ord("m"):
                volume.volume_mute()
                ctrl.log("Mute toggled [key]")

            elif key == ord("s"):
                import time as _t
                ts = _t.strftime("%Y%m%d_%H%M%S")
                p  = os.path.join(config.SCREENSHOT_DIR, f"manual_{ts}.png")
                saved, be = screenshot.take_screenshot(p, "full", frame)
                if saved: ctrl.log(f"Screenshot [{be}] → {os.path.basename(saved)}")

            elif key == ord("b"):
                from actions.window import _xdo
                _xdo("XF86MonBrightnessUp")
                ctrl.log("Brightness UP [key]")

            elif key == ord("v"):
                from actions.window import _xdo
                _xdo("XF86MonBrightnessDown")
                ctrl.log("Brightness DOWN [key]")

            elif key == ord("p"):
                volume.media_playpause()
                ctrl.log("Play/Pause [key]")

            elif key == ord("h"):
                window.minimize_window()
                ctrl.log("Minimize [key]")

            elif key == ord("w"):
                window.close_window()
                ctrl.log("Close window [key]")

            elif key == ord("x"):
                window.maximize_window()
                ctrl.log("Maximize [key]")

            elif key == ord("l"):
                window.lock_screen()
                ctrl.log("Lock screen [key]")

            elif key == ord("["):
                window.snap_left()
                ctrl.log("Snap left [key]")

            elif key == ord("]"):
                window.snap_right()
                ctrl.log("Snap right [key]")

    finally:
        cam.release()
        detector.close()
        cv2.destroyAllWindows()

        # Print stats for all modes that were used
        for name, ctrl in controllers.items():
            if ctrl.action_counts:
                ctrl.print_stats()


if __name__ == "__main__":
    main()
