#!/bin/bash
# Hand Gesture Control — Ubuntu/GNOME Installer
# Run: bash install.sh

set -e
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Hand Gesture Control — Ubuntu/GNOME Setup  ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

echo "[1/3] Python packages..."
pip install \
    "mediapipe==0.10.14" \
    "opencv-python>=4.8.0" \
    "pyautogui>=0.9.54" \
    "numpy>=1.24.0" \
    "pillow>=9.2.0" \
    --break-system-packages --quiet
echo "      Done."

echo "[2/3] System tools..."
sudo apt-get update -qq
sudo apt-get install -y \
    scrot xdotool playerctl \
    pulseaudio-utils wmctrl \
    brightnessctl xclip flameshot \
    gnome-screenshot --quiet
echo "      Done."

echo "[3/3] Permissions..."
sudo usermod -aG video "$USER" 2>/dev/null || true
echo "      Done."

echo ""
echo "── Verification ────────────────────────────────"
python3 -c "import mediapipe, cv2, pyautogui, numpy; from PIL import Image; print('  Python: OK')"
for t in scrot xdotool playerctl pactl wmctrl brightnessctl xclip; do
    command -v "$t" &>/dev/null && echo "  $t: OK" || echo "  $t: missing (non-critical)"
done

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Setup complete!                             ║"
echo "║                                              ║"
echo "║  Run:                                        ║"
echo "║    python3 main.py                 # system  ║"
echo "║    python3 main.py --mode vscode   # vscode  ║"
echo "║    python3 main.py --mode sublime  # sublime ║"
echo "║                                              ║"
echo "║  Press TAB in window to cycle modes          ║"
echo "╚══════════════════════════════════════════════╝"
