# modes/vscode_mode.py
# VS Code gesture mode — activated when VS Code window is focused.

from core.controller import BaseController
from actions import mouse, vscode as vs


class VSCodeMode(BaseController):
    """
    Gesture → VS Code action mapping.

    Gesture          Action
    ─────────────────────────────────────────────────────
    open_hand      → Run file (Ctrl+F5)
    fist           → Stop debug (Shift+F5)
    thumb_up       → Next tab (Ctrl+Tab)
    thumb_down     → Prev tab (Ctrl+Shift+Tab)
    pointing       → Move cursor  (continuous)
    peace          → Left click
    ok             → Right click
    pinch_scroll   → Scroll       (continuous)
    three_fingers  → Toggle terminal (Ctrl+`)
    four_fingers   → Command palette (Ctrl+Shift+P)
    middle_finger  → Format document (Ctrl+Shift+I)
    call_me        → Go to definition (F12)
    """

    MODE_NAME = "vscode"

    # Gesture → (function, log_label) table
    # Swap any entry here to remap a gesture without touching logic.
    BINDINGS = {
        "open_hand":     (vs.run_file,         "Run File         (Ctrl+F5)"),
        "fist":          (vs.stop_debug,        "Stop Debug       (Shift+F5)"),
        "thumb_up":      (vs.next_tab,          "Next Tab         (Ctrl+Tab)"),
        "thumb_down":    (vs.prev_tab,          "Prev Tab         (Ctrl+Shift+Tab)"),
        "peace":         (lambda: mouse.do_click("left"),  "Left Click"),
        "ok":            (lambda: mouse.do_click("right"), "Right Click"),
        "three_fingers": (vs.toggle_terminal,   "Toggle Terminal  (Ctrl+`)"),
        "four_fingers":  (vs.command_palette,   "Command Palette  (Ctrl+Shift+P)"),
        "middle_finger": (vs.format_document,   "Format Document  (Ctrl+Shift+I)"),
        "call_me":       (vs.go_to_definition,  "Go to Definition (F12)"),
    }

    def _dispatch(self, gesture, data):
        if gesture not in self.BINDINGS:
            return
        fn, label = self.BINDINGS[gesture]
        fn()
        self.log(f"[VS Code] {label}")
