# modes/system_mode.py
# System control mode — default mode for general desktop use.

from core.controller import BaseController
from actions import volume, mouse, screenshot, window


class SystemMode(BaseController):
    """
    Gesture → system action mapping for Ubuntu/GNOME desktop.

    Gesture          Action
    ─────────────────────────────────────────────────────
    open_hand      → Volume UP
    fist           → Volume DOWN
    thumb_up       → Next Track
    thumb_down     → Previous Track
    pointing       → Move cursor  (continuous)
    peace          → Left click
    ok             → Right click
    pinch_scroll   → Scroll       (continuous)
    three_fingers  → Alt+Tab
    four_fingers   → Show Desktop
    middle_finger  → Screenshot
    call_me        → Select-area screenshot
    """

    MODE_NAME = "system"

    def _dispatch(self, gesture, data):
        if gesture == "open_hand":
            volume.volume_up()
            v = volume.get_volume()
            self.log(f"OPEN HAND    → Volume UP  {f'({v}%)' if v else ''}")

        elif gesture == "fist":
            volume.volume_down()
            v = volume.get_volume()
            self.log(f"FIST         → Volume DOWN  {f'({v}%)' if v else ''}")

        elif gesture == "thumb_up":
            volume.media_next()
            self.log("THUMB UP     → Next Track")

        elif gesture == "thumb_down":
            volume.media_prev()
            self.log("THUMB DOWN   → Prev Track")

        elif gesture == "peace":
            mouse.do_click("left")
            self.log("PEACE        → Left Click")

        elif gesture == "ok":
            mouse.do_click("right")
            self.log("OK SIGN      → Right Click")

        elif gesture == "three_fingers":
            window.alt_tab()
            self.log("3 FINGERS    → Alt+Tab")

        elif gesture == "four_fingers":
            window.show_desktop()
            self.log("4 FINGERS    → Show Desktop")

        elif gesture == "middle_finger":
            import time, os
            from config import SCREENSHOT_DIR
            ts   = time.strftime("%Y%m%d_%H%M%S")
            path = os.path.join(SCREENSHOT_DIR, f"gesture_{ts}.png")
            saved, backend = screenshot.take_screenshot(path, "full", self._last_frame)
            if saved:
                screenshot.clipboard_copy_text(saved)
                self.log(f"SCREENSHOT   → {os.path.basename(saved)} [{backend}]")
            else:
                self.log(f"SCREENSHOT   → {backend}")

        elif gesture == "call_me":
            import time, os
            from config import SCREENSHOT_DIR
            ts   = time.strftime("%Y%m%d_%H%M%S")
            path = os.path.join(SCREENSHOT_DIR, f"select_{ts}.png")
            screenshot.take_screenshot(path, "select")
            self.log("CALL ME      → Select-area screenshot")
