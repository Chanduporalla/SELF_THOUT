# modes/sublime_mode.py
# Sublime Text gesture mode — activated when Sublime is focused.

from core.controller import BaseController
from actions import mouse, sublime as sb


class SublimeMode(BaseController):
    """
    Gesture → Sublime Text action mapping.

    Gesture          Action
    ─────────────────────────────────────────────────────
    open_hand      → Build / Run (F7)
    fist           → Cancel build
    thumb_up       → Next tab
    thumb_down     → Prev tab
    pointing       → Move cursor  (continuous)
    peace          → Left click
    ok             → Right click
    pinch_scroll   → Scroll       (continuous)
    three_fingers  → Toggle console (Ctrl+`)
    four_fingers   → Command palette (Ctrl+Shift+P)
    middle_finger  → Comment line (Ctrl+/)
    call_me        → Go to definition (F12)
    """

    MODE_NAME = "sublime"

    BINDINGS = {
        "open_hand":     (sb.build,              "Build / Run       (F7)"),
        "fist":          (sb.cancel_build,        "Cancel Build"),
        "thumb_up":      (sb.next_tab,            "Next Tab          (Ctrl+Tab)"),
        "thumb_down":    (sb.prev_tab,            "Prev Tab          (Ctrl+Shift+Tab)"),
        "peace":         (lambda: mouse.do_click("left"),  "Left Click"),
        "ok":            (lambda: mouse.do_click("right"), "Right Click"),
        "three_fingers": (sb.toggle_console,      "Toggle Console    (Ctrl+`)"),
        "four_fingers":  (sb.command_palette,     "Command Palette   (Ctrl+Shift+P)"),
        "middle_finger": (sb.comment_line,        "Comment Line      (Ctrl+/)"),
        "call_me":       (sb.go_to_definition,    "Go to Definition  (F12)"),
    }

    def _dispatch(self, gesture, data):
        if gesture not in self.BINDINGS:
            return
        fn, label = self.BINDINGS[gesture]
        fn()
        self.log(f"[Sublime] {label}")
