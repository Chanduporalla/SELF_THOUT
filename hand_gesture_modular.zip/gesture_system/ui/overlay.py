# ui/overlay.py
# OpenCV HUD overlay — draws the side panel onto the camera frame.

import cv2

# Gesture display metadata: color (RGB), short label, action hint
_INFO = {
    "open_hand":    ((0,   220, 120), "OPEN HAND",    "Vol UP / Run"),
    "fist":         ((0,   120, 255), "FIST",         "Vol DOWN / Stop"),
    "peace":        ((255, 200, 0),   "PEACE",        "Left Click"),
    "pointing":     ((210, 210, 210), "POINTING",     "Move Cursor"),
    "ok":           ((0,   255, 180), "OK SIGN",      "Right Click"),
    "pinch_scroll": ((160, 100, 255), "SCROLL",       "Scroll"),
    "three_fingers":((255, 140, 0),   "3 FINGERS",    "Terminal / Alt+Tab"),
    "four_fingers": ((255, 80,  140), "4 FINGERS",    "Palette / Desktop"),
    "thumb_up":     ((60,  255, 60),  "THUMB UP",     "Next / Prev Tab"),
    "thumb_down":   ((60,  60,  255), "THUMB DOWN",   "Prev / Next Tab"),
    "middle_finger":((255, 60,  60),  "MID FINGER",   "Screenshot / Format"),
    "call_me":      ((200, 60,  255), "CALL ME",      "Goto Def / Select"),
    "unknown":      ((65,  65,  65),  "--",           ""),
}

# Mode badge colors
_MODE_COL = {
    "system":  (150, 255, 190),
    "vscode":  (100, 180, 255),
    "sublime": (255, 160, 80),
}

PW = 348   # panel width in pixels

def _bgr(rgb): return (rgb[2], rgb[1], rgb[0])
def _txt(frame, text, pos, scale, color, thickness=1):
    cv2.putText(frame, text, pos, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness)


def draw(frame, gesture, mode_name, controller, fps, vol=None):
    """
    Draw the semi-transparent side panel onto frame (in-place).
    Returns frame for chaining.
    """
    h, w = frame.shape[:2]

    # Panel background
    panel = frame.copy()
    cv2.rectangle(panel, (0, 0), (PW, h), (6, 8, 18), -1)
    cv2.addWeighted(panel, 0.65, frame, 0.35, 0, frame)

    mode_col = _MODE_COL.get(mode_name, (180, 180, 180))

    # ── Header ──
    _txt(frame, "GESTURE CONTROL", (12, 28), 0.58, (150, 255, 190), 2)
    mode_lbl = {"system":"SYSTEM","vscode":"VS CODE","sublime":"SUBLIME"}
    cv2.rectangle(frame, (200, 12), (PW - 10, 36),
                  _bgr(mode_col), -1)
    _txt(frame, mode_lbl.get(mode_name, mode_name.upper()),
         (208, 29), 0.34, (0, 0, 0), 1)
    cv2.line(frame, (12, 40), (PW - 12, 40), (35, 65, 35), 1)

    # FPS + volume bar
    _txt(frame, f"FPS {fps:>3.0f}", (12, 56), 0.34, (90, 90, 90), 1)
    if vol is not None:
        bw = int((PW - 90) * min(vol, 100) / 100)
        cv2.rectangle(frame, (90, 46), (90 + bw, 60), (0, 160, 90), -1)
        cv2.rectangle(frame, (90, 46), (PW - 12, 60), (36, 72, 36), 1)
        _txt(frame, f"VOL {vol}%", (PW - 56, 58), 0.28, (0, 190, 110), 1)

    # ── Active gesture badge ──
    col, lbl, act = _INFO.get(gesture, _INFO["unknown"])
    cv2.rectangle(frame, (12, 64), (PW - 12, 102), _bgr(col), -1)
    cv2.rectangle(frame, (12, 64), (PW - 12, 102), (255, 255, 255), 1)
    _txt(frame, f"{lbl}  ->  {act}", (18, 90), 0.48, (0, 0, 0), 2)

    # ── Gesture table ──
    y = 112
    _txt(frame, "GESTURE         ACTION", (12, y), 0.30, (80, 140, 255), 1)

    for key, (dot, name, action) in _INFO.items():
        if key == "unknown": continue
        y += 15
        active = (gesture == key)
        cv2.circle(frame, (17, y - 3), 4,
                   _bgr(dot) if active else (34, 34, 34), -1)
        cv2.putText(frame, f"{name:<15} {action}", (27, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.28,
                    (255, 255, 255) if active else (140, 140, 140), 1)

    # ── Activity log ──
    y += 12
    cv2.line(frame, (12, y), (PW - 12, y), (35, 65, 35), 1)
    y += 12
    _txt(frame, "LOG", (12, y), 0.28, (80, 140, 255), 1)
    for entry in controller.gesture_log[-5:]:
        y += 12
        cv2.putText(frame, entry[-47:], (12, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.25, (128, 128, 128), 1)

    # ── Footer ──
    cv2.line(frame, (12, h - 22), (PW - 12, h - 22), (30, 50, 30), 1)
    _txt(frame, "Q=quit  M=mute  S=shot  B/V=bright  [mode: TAB]",
         (12, h - 9), 0.25, (58, 58, 58), 1)

    return frame
