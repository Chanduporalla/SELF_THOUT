# actions/screenshot.py
# Screenshot capture and clipboard integration.
# 6-layer fallback — never raises.

import os, subprocess, shutil, cv2
from config import SCREENSHOT_DIR

def _has(t): return shutil.which(t) is not None
def _run(cmd):
    try:
        r = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=4)
        return r.returncode == 0
    except Exception:
        return False


def take_screenshot(path=None, mode="full", fallback_frame=None):
    """
    Capture a screenshot.
    mode: 'full' | 'select' (interactive area selection)
    Returns (saved_path_or_None, backend_name).
    """
    if path is None:
        import time
        os.makedirs(SCREENSHOT_DIR, exist_ok=True)
        ts   = time.strftime("%Y%m%d_%H%M%S")
        path = os.path.join(SCREENSHOT_DIR, f"gesture_{ts}.png")

    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

    if mode == "select":
        return _screenshot_select(path)

    return _screenshot_full(path, fallback_frame)


def _screenshot_full(path, fallback_frame):
    # 1. scrot (fast, lightweight)
    if _has("scrot"):
        if _run(["scrot", path]) and os.path.exists(path):
            return path, "scrot"

    # 2. gnome-screenshot
    if _has("gnome-screenshot"):
        if _run(["gnome-screenshot", "-f", path]) and os.path.exists(path):
            return path, "gnome-screenshot"

    # 3. flameshot
    if _has("flameshot"):
        if _run(["flameshot", "full", "-p", os.path.dirname(path)]):
            return path, "flameshot"

    # 4. ImageMagick
    if _has("import"):
        if _run(["import", "-window", "root", path]) and os.path.exists(path):
            return path, "ImageMagick"

    # 5. Pillow
    try:
        from PIL import ImageGrab
        ImageGrab.grab().save(path)
        return path, "Pillow"
    except Exception:
        pass

    # 6. pyautogui
    try:
        import pyautogui
        pyautogui.screenshot(path)
        return path, "pyautogui"
    except Exception:
        pass

    # 7. Camera frame fallback — always works
    if fallback_frame is not None:
        cv2.imwrite(path, fallback_frame)
        return path, "camera-frame"

    return None, "FAILED — run: sudo apt install scrot"


def _screenshot_select(path):
    """Open an interactive area-selection tool."""
    if _has("flameshot"):
        subprocess.Popen(["flameshot", "gui"])
        return path, "flameshot (interactive)"
    if _has("gnome-screenshot"):
        subprocess.Popen(["gnome-screenshot", "-i"])
        return path, "gnome-screenshot (interactive)"
    if _has("scrot"):
        subprocess.Popen(["scrot", "-s", path])
        return path, "scrot (select)"
    return None, "No select-screenshot tool found"


# ── Clipboard ──────────────────────────────────────────────────

def clipboard_copy_text(text):
    """Write text to clipboard."""
    if _has("xclip"):
        try:
            subprocess.run(["xclip", "-selection", "clipboard"],
                           input=text, text=True, timeout=2)
            return True
        except Exception:
            pass
    if _has("xsel"):
        try:
            subprocess.run(["xsel", "--clipboard", "--input"],
                           input=text, text=True, timeout=2)
            return True
        except Exception:
            pass
    return False

def clipboard_get_text():
    """Read text from clipboard."""
    for cmd in [["xclip", "-selection", "clipboard", "-o"],
                ["xsel", "--clipboard", "--output"]]:
        if _has(cmd[0]):
            try:
                r = subprocess.run(cmd, stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL, text=True, timeout=2)
                if r.returncode == 0:
                    return r.stdout
            except Exception:
                pass
    return None
