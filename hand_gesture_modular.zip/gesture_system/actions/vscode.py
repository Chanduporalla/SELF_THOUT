# actions/vscode.py
# VS Code keyboard shortcuts mapped to gesture-friendly functions.
# All shortcuts use standard VS Code defaults (Linux).

from actions.mouse import hotkey, press


# ── Run & Debug ───────────────────────────────────────────────
def run_file():           hotkey("ctrl", "F5")          # Run without debug
def start_debug():        hotkey("F5")                   # Start / continue debug
def stop_debug():         hotkey("shift", "F5")          # Stop debug
def restart_debug():      hotkey("ctrl", "shift", "F5")  # Restart debug
def step_over():          press("F10")                   # Debug: step over
def step_into():          press("F11")                   # Debug: step into
def step_out():           hotkey("shift", "F11")         # Debug: step out
def toggle_breakpoint():  press("F9")                    # Toggle breakpoint


# ── Editor ────────────────────────────────────────────────────
def save_file():           hotkey("ctrl", "s")
def save_all():            hotkey("ctrl", "k", "s")
def undo():                hotkey("ctrl", "z")
def redo():                hotkey("ctrl", "shift", "z")
def comment_line():        hotkey("ctrl", "slash")       # Toggle line comment
def format_document():     hotkey("ctrl", "shift", "i")  # Format (Linux default)
def go_to_definition():    press("F12")
def peek_definition():     hotkey("alt", "F12")
def find_references():     hotkey("shift", "F12")
def rename_symbol():       press("F2")
def quick_fix():           hotkey("ctrl", "period")
def go_to_line():          hotkey("ctrl", "g")
def go_to_file():          hotkey("ctrl", "p")
def command_palette():     hotkey("ctrl", "shift", "p")
def select_all():          hotkey("ctrl", "a")
def duplicate_line():      hotkey("alt", "shift", "Down")
def delete_line():         hotkey("ctrl", "shift", "k")
def move_line_up():        hotkey("alt", "Up")
def move_line_down():      hotkey("alt", "Down")
def indent():              press("Tab")
def outdent():             hotkey("shift", "Tab")
def multi_cursor_add():    hotkey("ctrl", "alt", "Down") # Add cursor below


# ── Navigation ────────────────────────────────────────────────
def next_tab():            hotkey("ctrl", "Tab")
def prev_tab():            hotkey("ctrl", "shift", "Tab")
def close_tab():           hotkey("ctrl", "w")
def reopen_tab():          hotkey("ctrl", "shift", "t")
def split_editor():        hotkey("ctrl", "backslash")
def focus_next_group():    hotkey("ctrl", "F6")
def go_back():             hotkey("alt", "Left")
def go_forward():          hotkey("alt", "Right")
def next_error():          press("F8")
def prev_error():          hotkey("shift", "F8")
def fold_code():           hotkey("ctrl", "shift", "bracketleft")
def unfold_code():         hotkey("ctrl", "shift", "bracketright")


# ── Terminal & Panels ─────────────────────────────────────────
def toggle_terminal():     hotkey("ctrl", "grave")       # Ctrl+`
def toggle_sidebar():      hotkey("ctrl", "b")
def toggle_problems():     hotkey("ctrl", "shift", "m")
def toggle_explorer():     hotkey("ctrl", "shift", "e")
def toggle_search():       hotkey("ctrl", "shift", "f")
def toggle_git():          hotkey("ctrl", "shift", "g")
def toggle_extensions():   hotkey("ctrl", "shift", "x")
def zen_mode():            hotkey("ctrl", "k", "z")


# ── Git ───────────────────────────────────────────────────────
def git_commit():
    command_palette()
    import time; time.sleep(0.3)
    from actions.mouse import typewrite
    typewrite("Git: Commit", interval=0.02)
    press("Return")

def git_push():
    command_palette()
    import time; time.sleep(0.3)
    from actions.mouse import typewrite
    typewrite("Git: Push", interval=0.02)
    press("Return")
