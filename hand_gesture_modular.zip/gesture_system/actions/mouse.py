# actions/mouse.py
# Mouse movement, clicks, scroll, keyboard hotkeys.

import subprocess, shutil
import pyautogui

pyautogui.FAILSAFE = False
pyautogui.PAUSE    = 0

def _has(t): return shutil.which(t) is not None
def _xdo(key):
    if _has("xdotool"):
        subprocess.run(["xdotool", "key", "--clearmodifiers", key],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        try: pyautogui.press(key)
        except Exception: pass


# ── Mouse ──────────────────────────────────────────────────────

def do_move(x, y):
    try: pyautogui.moveTo(int(x), int(y))
    except Exception: pass

def do_scroll(amount):
    try: pyautogui.scroll(amount)
    except Exception: pass

def do_click(button="left"):
    try:
        {"left":   pyautogui.click,
         "right":  pyautogui.rightClick,
         "double": pyautogui.doubleClick,
         "middle": pyautogui.middleClick}[button]()
    except Exception as e:
        print(f"[WARN] click({button}): {e}")

def do_drag_start():
    try: pyautogui.mouseDown()
    except Exception: pass

def do_drag_end():
    try: pyautogui.mouseUp()
    except Exception: pass


# ── Keyboard helpers ───────────────────────────────────────────

def hotkey(*keys):
    """e.g. hotkey('ctrl','s') — uses xdotool when available."""
    if _has("xdotool"):
        combo = "+".join(keys)
        subprocess.run(["xdotool", "key", "--clearmodifiers", combo],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        try: pyautogui.hotkey(*keys)
        except Exception: pass

def press(key):
    """Single keypress."""
    _xdo(key)

def typewrite(text, interval=0.05):
    try: pyautogui.typewrite(text, interval=interval)
    except Exception: pass
