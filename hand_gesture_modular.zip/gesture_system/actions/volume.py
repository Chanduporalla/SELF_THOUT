# actions/volume.py
# Volume control and media playback — Ubuntu/GNOME optimized.
# Backends: pactl (PipeWire/PulseAudio) → amixer → xdotool → pyautogui

import subprocess, shutil, re
import pyautogui
from config import VOLUME_STEP

def _has(t): return shutil.which(t) is not None
def _run(cmd):
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           timeout=3, text=True)
        return r.returncode == 0, r.stdout.strip()
    except Exception:
        return False, ""


def volume_up():
    _set_volume(f"+{VOLUME_STEP}%")

def volume_down():
    _set_volume(f"-{VOLUME_STEP}%")

def volume_mute():
    if _has("pactl"):
        _run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]); return
    if _has("amixer"):
        _run(["amixer", "-q", "sset", "Master", "toggle"]); return
    if _has("xdotool"):
        _run(["xdotool", "key", "XF86AudioMute"]); return
    pyautogui.press("volumemute")

def get_volume():
    """Return current volume 0–100, or None."""
    if _has("pactl"):
        ok, out = _run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"])
        if ok:
            nums = re.findall(r"(\d+)%", out)
            if nums: return int(nums[0])
    return None

def _set_volume(step):
    if _has("pactl"):
        _run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", step]); return
    if _has("amixer"):
        val = f"{VOLUME_STEP}%+" if "+" in step else f"{VOLUME_STEP}%-"
        _run(["amixer", "-q", "sset", "Master", val]); return
    if _has("xdotool"):
        key = "XF86AudioRaiseVolume" if "+" in step else "XF86AudioLowerVolume"
        _run(["xdotool", "key", key]); return
    pyautogui.press("volumeup" if "+" in step else "volumedown")


# ── Media ──────────────────────────────────────────────────────

def media_next():      _media("next")
def media_prev():      _media("prev")
def media_playpause(): _media("play")
def media_stop():      _media("stop")

def _media(action):
    pc  = {"next":"next", "prev":"previous", "play":"play-pause", "stop":"stop"}
    xdo = {"next":"XF86AudioNext","prev":"XF86AudioPrev",
           "play":"XF86AudioPlay","stop":"XF86AudioStop"}
    pag = {"next":"nexttrack","prev":"prevtrack","play":"playpause","stop":"stop"}

    if _has("playerctl"):
        # Prefer Spotify or VLC if running
        ok, players = _run(["playerctl", "-l"])
        if ok and players:
            for p in ["spotify", "vlc", "rhythmbox", "mpv"]:
                if p in players.lower():
                    _run(["playerctl", "--player", p, pc[action]])
                    return
        _run(["playerctl", pc[action]]); return

    if _has("xdotool"):
        _run(["xdotool", "key", xdo[action]]); return

    try: pyautogui.press(pag[action])
    except Exception: pass
