# actions/sublime.py
# Sublime Text keyboard shortcuts mapped to gesture-friendly functions.
# Covers Sublime Text 3 & 4 (Linux defaults).

from actions.mouse import hotkey, press


# ── Run & Build ───────────────────────────────────────────────
def build():              press("F7")                    # Build / run current file
def build_with():         hotkey("ctrl", "shift", "b")   # Choose build system
def cancel_build():       hotkey("ctrl", "break")


# ── Editor ────────────────────────────────────────────────────
def save_file():          hotkey("ctrl", "s")
def save_all():           hotkey("ctrl", "alt", "s")
def undo():               hotkey("ctrl", "z")
def redo():               hotkey("ctrl", "shift", "z")
def comment_line():       hotkey("ctrl", "slash")        # Toggle line comment
def block_comment():      hotkey("ctrl", "shift", "slash")
def format_document():    hotkey("ctrl", "shift", "p")   # Opens command palette → reindent
def go_to_definition():   press("F12")
def go_to_symbol():       hotkey("ctrl", "r")            # In file
def go_to_symbol_global():hotkey("ctrl", "shift", "r")   # Across project
def goto_line():          hotkey("ctrl", "g")
def goto_file():          hotkey("ctrl", "p")
def command_palette():    hotkey("ctrl", "shift", "p")
def select_all():         hotkey("ctrl", "a")
def expand_selection():   hotkey("ctrl", "shift", "space")
def select_line():        hotkey("ctrl", "l")
def duplicate_line():     hotkey("ctrl", "shift", "d")
def delete_line():        hotkey("ctrl", "shift", "k")
def join_lines():         hotkey("ctrl", "j")
def move_line_up():       hotkey("ctrl", "shift", "Up")
def move_line_down():     hotkey("ctrl", "shift", "Down")
def indent():             press("Tab")
def outdent():            hotkey("shift", "Tab")
def sort_lines():         press("F9")
def upper_case():         hotkey("ctrl", "k", "u")
def lower_case():         hotkey("ctrl", "k", "l")


# ── Multi-cursor & Selection ──────────────────────────────────
def multi_select_next():     hotkey("ctrl", "d")          # Select next occurrence
def multi_select_all():      hotkey("alt", "F3")          # Select all occurrences
def multi_cursor_above():    hotkey("ctrl", "alt", "Up")
def multi_cursor_below():    hotkey("ctrl", "alt", "Down")
def split_into_lines():      hotkey("ctrl", "shift", "l") # Multi-cursor per line


# ── Navigation ────────────────────────────────────────────────
def next_tab():           hotkey("ctrl", "Tab")
def prev_tab():           hotkey("ctrl", "shift", "Tab")
def close_tab():          hotkey("ctrl", "w")
def reopen_tab():         hotkey("ctrl", "shift", "t")
def next_file():          hotkey("ctrl", "F6")
def prev_file():          hotkey("ctrl", "shift", "F6")
def split_2_columns():    hotkey("alt", "shift", "2")
def split_1_column():     hotkey("alt", "shift", "1")
def focus_group_1():      hotkey("ctrl", "1")
def focus_group_2():      hotkey("ctrl", "2")
def jump_back():          hotkey("alt", "minus")
def jump_forward():       hotkey("alt", "shift", "minus")
def fold():               hotkey("ctrl", "shift", "bracketleft")
def unfold():             hotkey("ctrl", "shift", "bracketright")
def fold_all():           hotkey("ctrl", "k", "1")
def unfold_all():         hotkey("ctrl", "k", "0")


# ── Find ──────────────────────────────────────────────────────
def find():               hotkey("ctrl", "f")
def find_replace():       hotkey("ctrl", "h")
def find_in_files():      hotkey("ctrl", "shift", "f")
def find_next():          press("F3")
def find_prev():          hotkey("shift", "F3")


# ── Panels ────────────────────────────────────────────────────
def toggle_console():     hotkey("ctrl", "grave")
def toggle_sidebar():     hotkey("ctrl", "k", "b")
def distraction_free():   hotkey("shift", "F11")
def fullscreen():         press("F11")
