# actions/window.py
# Window management — Ubuntu/GNOME.
# Backends: xdotool → wmctrl → pyautogui hotkeys.

import subprocess, shutil
import pyautogui

def _has(t): return shutil.which(t) is not None
def _run(cmd):
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           timeout=3, text=True)
        return r.returncode == 0, r.stdout.strip()
    except Exception:
        return False, ""
def _xdo(key):
    if _has("xdotool"):
        subprocess.run(["xdotool", "key", "--clearmodifiers", key],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        try: pyautogui.hotkey(*key.split("+"))
        except Exception: pass


def alt_tab():
    _xdo("alt+Tab")

def show_desktop():
    if _has("wmctrl"):
        _run(["wmctrl", "-k", "on"]); return
    _xdo("super+d")

def maximize_window():
    if _has("xdotool"):
        ok, wid = _run(["xdotool", "getactivewindow"])
        if ok and wid:
            _run(["xdotool", "windowmaximize", wid]); return
    if _has("wmctrl"):
        _run(["wmctrl", "-r", ":ACTIVE:", "-b", "add,maximized_vert,maximized_horz"]); return
    _xdo("super+Up")

def minimize_window():
    if _has("xdotool"):
        ok, wid = _run(["xdotool", "getactivewindow"])
        if ok and wid:
            _run(["xdotool", "windowminimize", wid]); return
    _xdo("super+h")

def close_window():
    _xdo("alt+F4")

def snap_left():
    _xdo("super+Left")

def snap_right():
    _xdo("super+Right")

def next_workspace():
    _xdo("ctrl+alt+Right")

def prev_workspace():
    _xdo("ctrl+alt+Left")

def lock_screen():
    if _has("loginctl"):
        _run(["loginctl", "lock-session"]); return
    if _has("gnome-screensaver-command"):
        _run(["gnome-screensaver-command", "-l"]); return
    _xdo("super+l")

def get_active_window_title():
    """Return lowercase title of the currently focused window, or ''."""
    if _has("xdotool"):
        ok, wid = _run(["xdotool", "getactivewindow"])
        if ok and wid:
            ok2, title = _run(["xdotool", "getwindowname", wid])
            if ok2:
                return title.lower()
    if _has("wmctrl"):
        ok, out = _run(["wmctrl", "-l"])
        # wmctrl doesn't easily surface active window without extra work
    return ""
