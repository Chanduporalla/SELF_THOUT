# core/classifier.py
# Pure geometry — classifies a hand landmark array into a gesture name.
# No side-effects; no imports of actions or UI.

import math
import numpy as np
from config import PINCH_THRESHOLD, SCREEN_W, SCREEN_H

# ── Landmark indices ──────────────────────────────────────────
WRIST      = 0
THUMB_CMC  = 1;  THUMB_MCP  = 2;  THUMB_IP   = 3;  THUMB_TIP  = 4
INDEX_MCP  = 5;  INDEX_PIP  = 6;  INDEX_DIP  = 7;  INDEX_TIP  = 8
MIDDLE_MCP = 9;  MIDDLE_PIP = 10; MIDDLE_DIP = 11; MIDDLE_TIP = 12
RING_MCP   = 13; RING_PIP   = 14; RING_DIP   = 15; RING_TIP   = 16
PINKY_MCP  = 17; PINKY_PIP  = 18; PINKY_DIP  = 19; PINKY_TIP  = 20


# ── Geometry helpers ──────────────────────────────────────────

def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

def norm_dist(pts, i, j, ref):
    return dist(pts[i], pts[j]) / (ref + 1e-6)

def finger_up(pts, tip, pip):
    """True when fingertip is farther from wrist than PIP × 1.15."""
    return dist(pts[tip], pts[WRIST]) > dist(pts[pip], pts[WRIST]) * 1.15

def thumb_extended(pts):
    return dist(pts[THUMB_TIP], pts[WRIST]) > dist(pts[THUMB_IP], pts[WRIST]) * 1.1


# ── Main classifier ───────────────────────────────────────────

def classify(pts, frame_w, frame_h):
    """
    Given a (21, 3) landmark array and frame dimensions,
    returns (gesture_name: str, extra: dict).

    Gestures returned:
      open_hand, fist, thumb_up, thumb_down,
      four_fingers, three_fingers, peace,
      pointing, ok, pinch_scroll,
      middle_finger, call_me, unknown
    """
    ref   = dist(pts[WRIST], pts[MIDDLE_MCP])  # palm size reference
    idx   = finger_up(pts, INDEX_TIP,  INDEX_PIP)
    mid   = finger_up(pts, MIDDLE_TIP, MIDDLE_PIP)
    rng   = finger_up(pts, RING_TIP,   RING_PIP)
    pky   = finger_up(pts, PINKY_TIP,  PINKY_PIP)
    thb   = thumb_extended(pts)
    count = sum([idx, mid, rng, pky])
    pd    = norm_dist(pts, THUMB_TIP, INDEX_TIP, ref)
    pinch = pd < PINCH_THRESHOLD

    # Ordered by specificity (most specific first)
    if count == 4 and thb:
        return "open_hand", {}

    if count == 0 and not thb:
        return "fist", {}

    if thb and count == 0:
        up = pts[THUMB_TIP][1] < pts[THUMB_CMC][1]
        return ("thumb_up" if up else "thumb_down"), {}

    if idx and mid and rng and pky and not thb:
        return "four_fingers", {}

    if idx and mid and rng and not pky:
        return "three_fingers", {}

    if idx and mid and not rng and not pky:
        return "peace", {}

    if idx and not mid and not rng and not pky:
        tip = pts[INDEX_TIP]
        return "pointing", {
            "x": float(np.interp(tip[0], [0, frame_w], [0, SCREEN_W])),
            "y": float(np.interp(tip[1], [0, frame_h], [0, SCREEN_H])),
            "tip_y": float(tip[1]),
        }

    if pinch and not mid and not rng and not pky:
        return "ok", {}

    if pinch and mid and not rng and not pky:
        return "pinch_scroll", {"tip_y": float(pts[INDEX_TIP][1])}

    if not idx and mid and not rng and not pky:
        return "middle_finger", {}

    if thb and pky and not idx and not mid and not rng:
        return "call_me", {}

    return "unknown", {}
