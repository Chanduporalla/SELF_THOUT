# core/camera.py
# Handles webcam capture and frame preprocessing.

import cv2
from config import CAMERA_INDEX, FRAME_W, FRAME_H, CAMERA_FPS


class Camera:
    def __init__(self):
        self.cap = None
        self._last_frame = None

    def open(self):
        self.cap = cv2.VideoCapture(CAMERA_INDEX)
        if not self.cap.isOpened():
            raise RuntimeError(
                f"Cannot open camera {CAMERA_INDEX}. "
                "Try changing CAMERA_INDEX in config.py (e.g. 1 or 2)."
            )
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  FRAME_W)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_H)
        self.cap.set(cv2.CAP_PROP_FPS,          CAMERA_FPS)
        return self

    def read(self):
        """
        Returns (frame_bgr, frame_rgb) with horizontal flip applied,
        or (None, None) on failure.
        """
        if self.cap is None:
            return None, None
        ok, frame = self.cap.read()
        if not ok:
            return None, None
        frame = cv2.flip(frame, 1)
        self._last_frame = frame.copy()
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        return frame, rgb

    @property
    def last_frame(self):
        return self._last_frame

    def release(self):
        if self.cap:
            self.cap.release()
            self.cap = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *_):
        self.release()
