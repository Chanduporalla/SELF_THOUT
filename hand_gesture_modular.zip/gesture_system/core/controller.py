# core/controller.py
# Base gesture controller — handles cooldown, logging, scroll state.
# Subclassed by each mode (system, vscode, sublime).

import time
from config import GESTURE_COOLDOWN, CURSOR_SMOOTHING, SCROLL_SENSITIVITY, SCREEN_W, SCREEN_H


class BaseController:
    """
    Handles:
      - cooldown gating for discrete gestures
      - smooth cursor tracking for 'pointing'
      - continuous scroll tracking for 'pinch_scroll'
      - rolling activity log
      - per-gesture action counts (session stats)

    Subclasses override _dispatch(gesture, data) to define
    what each gesture does in that mode.
    """

    MODE_NAME = "base"   # override in subclass

    def __init__(self):
        self.last_gesture      = "unknown"
        self.last_trigger_time = 0.0
        self.smooth_x          = float(SCREEN_W // 2)
        self.smooth_y          = float(SCREEN_H // 2)
        self.prev_scroll_y     = None
        self.gesture_log       = []          # list of log strings (rolling)
        self.action_counts     = {}          # gesture → count
        self._last_frame       = None        # latest camera frame (for screenshot fallback)

    # ── Frame ──────────────────────────────────────────────────
    def set_frame(self, frame):
        self._last_frame = frame

    # ── Logging ────────────────────────────────────────────────
    def log(self, msg):
        entry = f"[{time.strftime('%H:%M:%S')}] {msg}"
        self.gesture_log.append(entry)
        if len(self.gesture_log) > 8:
            self.gesture_log.pop(0)
        print(entry)

    # ── Cooldown ───────────────────────────────────────────────
    def _cooldown_ok(self):
        return (time.time() - self.last_trigger_time) > GESTURE_COOLDOWN

    def _reset_cooldown(self):
        self.last_trigger_time = time.time()

    # ── Main entry point ───────────────────────────────────────
    def execute(self, gesture, data):
        """
        Called every frame with the detected gesture + extra data.
        Returns the gesture string that was processed.
        """
        # Continuous gesture: cursor movement (no cooldown)
        if gesture == "pointing":
            self._handle_pointing(data)
            return gesture

        # Continuous gesture: scroll (no cooldown)
        if gesture == "pinch_scroll":
            self._handle_scroll(data)
            return gesture

        # Reset scroll state when not scrolling
        self.prev_scroll_y = None

        # Discrete gesture: cooldown-gated
        if not self._cooldown_ok():
            return self.last_gesture

        self._reset_cooldown()
        self.last_gesture = gesture
        self.action_counts[gesture] = self.action_counts.get(gesture, 0) + 1

        try:
            self._dispatch(gesture, data)
        except Exception as e:
            self.log(f"[ERR] {gesture}: {e}")

        return gesture

    # ── Subclass interface ─────────────────────────────────────
    def _dispatch(self, gesture, data):
        """Override in subclass to map gestures → actions."""
        pass

    # ── Built-in continuous handlers ──────────────────────────
    def _handle_pointing(self, data):
        from actions.mouse import do_move
        try:
            self.smooth_x += (data["x"] - self.smooth_x) * CURSOR_SMOOTHING
            self.smooth_y += (data["y"] - self.smooth_y) * CURSOR_SMOOTHING
            do_move(self.smooth_x, self.smooth_y)
        except Exception:
            pass

    def _handle_scroll(self, data):
        from actions.mouse import do_scroll
        tip_y = data.get("tip_y")
        if tip_y is None:
            return
        if self.prev_scroll_y is not None:
            delta = tip_y - self.prev_scroll_y
            if abs(delta) > 1.5:
                do_scroll(-int(delta * SCROLL_SENSITIVITY))
        self.prev_scroll_y = tip_y

    # ── Stats ──────────────────────────────────────────────────
    def print_stats(self):
        if not self.action_counts:
            return
        print(f"\n── {self.MODE_NAME.upper()} Session Stats ──")
        mx = max(self.action_counts.values())
        for g, cnt in sorted(self.action_counts.items(), key=lambda x: -x[1]):
            bar = "█" * int(cnt / mx * 20)
            print(f"  {g:<22} {cnt:>4}x  {bar}")
        print(f"\n  Total: {sum(self.action_counts.values())} gestures\n")
