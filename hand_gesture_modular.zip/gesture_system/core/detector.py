# core/detector.py
# MediaPipe hand detection wrapper.

import mediapipe as mp
import numpy as np
from config import MAX_HANDS, MIN_DETECTION_CONF, MIN_TRACKING_CONF, MODEL_COMPLEXITY

mp_hands   = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_styles  = mp.solutions.drawing_styles


class HandDetector:
    def __init__(self):
        self._hands = None

    def start(self):
        self._hands = mp_hands.Hands(
            model_complexity         = MODEL_COMPLEXITY,
            max_num_hands            = MAX_HANDS,
            min_detection_confidence = MIN_DETECTION_CONF,
            min_tracking_confidence  = MIN_TRACKING_CONF,
        )
        return self

    def process(self, rgb_frame):
        """
        Returns list of landmark arrays (shape N×3, pixel coords).
        Empty list if no hands found.
        """
        if self._hands is None:
            return []
        results = self._hands.process(rgb_frame)
        if not results.multi_hand_landmarks:
            return []
        h, w = rgb_frame.shape[:2]
        return [self._to_np(lm, w, h) for lm in results.multi_hand_landmarks]

    def draw(self, frame, rgb_frame):
        """
        Draw hand skeleton onto frame (in-place).
        Returns the same frame for chaining.
        """
        results = self._hands.process(rgb_frame)
        if results.multi_hand_landmarks:
            for lm in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(
                    frame, lm,
                    mp_hands.HAND_CONNECTIONS,
                    mp_styles.get_default_hand_landmarks_style(),
                    mp_styles.get_default_hand_connections_style(),
                )
        return frame

    def process_and_draw(self, frame, rgb_frame):
        """
        Combined detect + draw in one MediaPipe call.
        Returns (landmark_arrays, annotated_frame).
        """
        if self._hands is None:
            return [], frame
        results = self._hands.process(rgb_frame)
        landmarks = []
        if results.multi_hand_landmarks:
            h, w = rgb_frame.shape[:2]
            for lm in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(
                    frame, lm,
                    mp_hands.HAND_CONNECTIONS,
                    mp_styles.get_default_hand_landmarks_style(),
                    mp_styles.get_default_hand_connections_style(),
                )
                landmarks.append(self._to_np(lm, w, h))
        return landmarks, frame

    @staticmethod
    def _to_np(lm, w, h):
        return np.array([[p.x * w, p.y * h, p.z] for p in lm.landmark])

    def close(self):
        if self._hands:
            self._hands.close()
            self._hands = None

    def __enter__(self):
        return self.start()

    def __exit__(self, *_):
        self.close()
