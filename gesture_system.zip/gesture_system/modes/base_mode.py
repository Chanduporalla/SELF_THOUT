# modes/base_mode.py
"""
Base class for all gesture mode controllers.
"""
import time
import config


class BaseMode:
    NAME = "base"

    def __init__(self):
        self._frame       = None
        self._last_action = 0.0
        self._log_lines   = []          # last N log entries
        self._log_max     = 8
        self.action_counts = {}         # gesture_name → int

    # ── Frame ──────────────────────────────────────────────────
    def set_frame(self, frame):
        self._frame = frame

    # ── Cooldown ───────────────────────────────────────────────
    def _ready(self):
        return (time.time() - self._last_action) >= config.GESTURE_COOLDOWN

    def _mark(self):
        self._last_action = time.time()

    def _act(self, gesture, fn, *args, **kwargs):
        """Run fn(*args) if cooldown has elapsed; log and count the gesture."""
        if self._ready():
            fn(*args, **kwargs)
            self._mark()
            self.log(gesture)
            self.action_counts[gesture] = self.action_counts.get(gesture, 0) + 1
            return gesture
        return None

    # ── Logging ────────────────────────────────────────────────
    def log(self, msg):
        ts = time.strftime("%H:%M:%S")
        entry = f"[{ts}] {msg}"
        self._log_lines.append(entry)
        if len(self._log_lines) > self._log_max:
            self._log_lines.pop(0)

    def get_log(self):
        return list(self._log_lines)

    # ── Stats ──────────────────────────────────────────────────
    def print_stats(self):
        print(f"\n── {self.NAME} mode stats ──")
        for g, n in sorted(self.action_counts.items(), key=lambda x: -x[1]):
            print(f"  {g:<20} {n:>4}×")

    # ── Override in subclass ───────────────────────────────────
    def execute(self, gesture, extra):
        """
        Process a classified gesture.
        Returns the gesture string that was handled (or "unknown").
        """
        raise NotImplementedError
