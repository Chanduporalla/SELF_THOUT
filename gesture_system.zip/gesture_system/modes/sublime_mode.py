# modes/sublime_mode.py
"""
Sublime Text mode — editor-focused gesture shortcuts.

Gesture map
───────────
point      → move cursor
pinch      → click
peace      → scroll
open_palm  → toggle side bar  (Ctrl+K, Ctrl+B)
fist       → comment toggle   (Ctrl+/)
thumb_up   → increase font    (Ctrl+=)
thumb_down → decrease font    (Ctrl+-)
three      → go to definition  (F12 / via plugin)
four       → command palette   (Ctrl+Shift+P)
pinky      → close tab         (Ctrl+W)
"""

import config
from modes.base_mode import BaseMode
from actions.mouse import move, click, scroll, hotkey, press


class SublimeMode(BaseMode):
    NAME = "sublime"

    def __init__(self):
        super().__init__()
        self._prev_nx = None
        self._sx      = 0.0
        self._sy      = 0.0

    def execute(self, gesture, extra):
        W, H = config.SCREEN_W, config.SCREEN_H
        α    = config.CURSOR_SMOOTHING

        if gesture == "point":
            nx, ny = extra["nx"], extra["ny"]
            if self._prev_nx is None:
                self._sx, self._sy = nx, ny
            else:
                self._sx = self._sx + α * (nx - self._sx)
                self._sy = self._sy + α * (ny - self._sy)
            self._prev_nx = nx
            move(int(self._sx * W), int(self._sy * H))
            return "point"

        if gesture != "point":
            self._prev_nx = None

        if gesture == "pinch":
            self._act("click", click)
            return "pinch"

        if gesture == "peace":
            ny = extra.get("ny", 0.5)
            if ny < 0.4:
                scroll(config.SCROLL_SENSITIVITY)
            elif ny > 0.6:
                scroll(-config.SCROLL_SENSITIVITY)
            return "peace"

        if gesture == "open_palm":
            # Sublime sidebar: Ctrl+K then Ctrl+B
            if self._ready():
                hotkey("ctrl", "k")
                hotkey("ctrl", "b")
                self._mark()
                self.log("sidebar")
            return "open_palm"

        if gesture == "fist":
            self._act("comment", hotkey, "ctrl", "/")
            return "fist"

        if gesture == "thumb_up":
            self._act("font+", hotkey, "ctrl", "=")
            return "thumb_up"

        if gesture == "thumb_down":
            self._act("font-", hotkey, "ctrl", "-")
            return "thumb_down"

        if gesture == "three":
            self._act("go-def", press, "f12")
            return "three"

        if gesture == "four":
            self._act("palette", hotkey, "ctrl", "shift", "p")
            return "four"

        if gesture == "pinky":
            self._act("close-tab", hotkey, "ctrl", "w")
            return "pinky"

        return gesture
