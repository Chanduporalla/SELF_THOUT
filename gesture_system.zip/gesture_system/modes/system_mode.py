# modes/system_mode.py
"""
System mode — general OS control gestures.

Gesture map
───────────
point      → move mouse cursor
pinch      → left click
peace      → scroll (index+middle up; ny < 0.4 = up, ny > 0.6 = down)
open_palm  → screenshot
fist       → (hold) drag / (release) drop
thumb_up   → volume up
thumb_down → volume down
three      → media play/pause
four       → mute toggle
pinky      → lock screen
"""

import config
from modes.base_mode import BaseMode
from actions import volume, screenshot, window
from actions.mouse import move, click, scroll, hotkey
import os, time


class SystemMode(BaseMode):
    NAME = "system"

    def __init__(self):
        super().__init__()
        self._prev_nx   = None
        self._prev_ny   = None
        self._dragging  = False
        self._sx        = 0.0   # smoothed cursor x (normalised)
        self._sy        = 0.0   # smoothed cursor y (normalised)

    def execute(self, gesture, extra):
        W, H = config.SCREEN_W, config.SCREEN_H
        α    = config.CURSOR_SMOOTHING

        # ── Cursor move ──────────────────────────────────────
        if gesture == "point":
            nx, ny = extra["nx"], extra["ny"]
            if self._prev_nx is None:
                self._sx, self._sy = nx, ny
            else:
                self._sx = self._sx + α * (nx - self._sx)
                self._sy = self._sy + α * (ny - self._sy)
            self._prev_nx, self._prev_ny = nx, ny
            move(int(self._sx * W), int(self._sy * H))
            if self._dragging:
                return "drag"
            return "point"

        # Reset smoothing when hand leaves pointing pose
        if gesture != "point":
            self._prev_nx = None

        # ── Click ────────────────────────────────────────────
        if gesture == "pinch":
            self._act("click", click)
            return "pinch"

        # ── Scroll ───────────────────────────────────────────
        if gesture == "peace":
            ny = extra.get("ny", 0.5)
            if ny < 0.4:
                scroll(config.SCROLL_SENSITIVITY)
            elif ny > 0.6:
                scroll(-config.SCROLL_SENSITIVITY)
            return "peace"

        # ── Screenshot ───────────────────────────────────────
        if gesture == "open_palm":
            if self._ready():
                ts  = time.strftime("%Y%m%d_%H%M%S")
                p   = os.path.join(config.SCREENSHOT_DIR, f"gesture_{ts}.png")
                saved, be = screenshot.take_screenshot(p, "full", self._frame)
                if saved:
                    self.log(f"Screenshot [{be}]")
                self._mark()
            return "open_palm"

        # ── Volume ───────────────────────────────────────────
        if gesture == "thumb_up":
            self._act("vol_up", volume.volume_up)
            return "thumb_up"

        if gesture == "thumb_down":
            self._act("vol_down", volume.volume_down)
            return "thumb_down"

        # ── Media ────────────────────────────────────────────
        if gesture == "three":
            self._act("play_pause", volume.media_playpause)
            return "three"

        # ── Mute ─────────────────────────────────────────────
        if gesture == "four":
            self._act("mute", volume.volume_mute)
            return "four"

        # ── Lock screen ──────────────────────────────────────
        if gesture == "pinky":
            self._act("lock", window.lock_screen)
            return "pinky"

        return gesture
