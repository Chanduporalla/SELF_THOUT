# Hand Gesture Control System

Control your computer with hand gestures via webcam — works on **Linux** and **Windows**.

---

## Quick Start

### Linux
```bash
cd gesture_system
bash setup_linux.sh
source venv/bin/activate
python3 main.py
```

### Windows
```
Double-click setup_windows.bat
Then double-click run.bat
```

---

## Gesture Reference

| Gesture | System mode | VS Code mode | Sublime mode |
|---|---|---|---|
| ☝️ Index finger (point) | Move cursor | Move cursor | Move cursor |
| 🤏 Pinch (thumb+index) | Left click | Left click | Left click |
| ✌️ Peace (index+middle) | Scroll up/down | Scroll up/down | Scroll up/down |
| 🖐️ Open palm | Screenshot | Toggle sidebar | Toggle sidebar |
| ✊ Fist | — | Toggle comment | Toggle comment |
| 👍 Thumb up | Volume up | Font size up | Font size up |
| 👎 Thumb down | Volume down | Font size down | Font size down |
| 3️⃣ Three fingers | Play/Pause | Go to definition | Go to definition |
| 4️⃣ Four fingers | Mute toggle | Format document | Command palette |
| 🤙 Pinky only | Lock screen | Close tab | Close tab |

**Scroll direction:** Hold peace sign — raise hand above centre to scroll up, lower to scroll down.

---

## Keyboard Shortcuts (camera window focused)

| Key | Action |
|---|---|
| `TAB` | Cycle through modes |
| `Q` | Quit |
| `M` | Toggle mute |
| `S` | Take screenshot |
| `P` | Play/Pause media |
| `H` | Minimise window |
| `W` | Close window |
| `X` | Maximise window |
| `L` | Lock screen |
| `[` | Snap window left |
| `]` | Snap window right |
| `B` / `V` | Brightness up/down (Linux) |

---

## Modes

| Mode | Auto-detected when… |
|---|---|
| `system` | No IDE window in focus |
| `vscode` | VS Code window is focused |
| `sublime` | Sublime Text window is focused |

Auto-switching can be disabled with `--no-auto`.

---

## Configuration (`config.py`)

| Setting | Default | Description |
|---|---|---|
| `CAMERA_INDEX` | `0` | Webcam index (0 = default) |
| `GESTURE_COOLDOWN` | `0.65` | Seconds between triggered actions |
| `CURSOR_SMOOTHING` | `0.18` | Cursor lag (0=frozen, 1=instant) |
| `PINCH_THRESHOLD` | `0.055` | How close thumb+index must be |
| `SCROLL_SENSITIVITY` | `12` | Scroll speed |
| `VOLUME_STEP` | `5` | Volume % per gesture |

---

## Project Structure

```
gesture_system/
├── main.py               ← Entry point
├── config.py             ← All settings
├── requirements.txt      ← Python dependencies
├── setup_linux.sh        ← Linux setup script
├── setup_windows.bat     ← Windows setup script
├── core/
│   ├── camera.py         ← Webcam capture
│   ├── detector.py       ← MediaPipe hand detection
│   └── classifier.py     ← Gesture classification
├── modes/
│   ├── base_mode.py      ← Shared mode logic
│   ├── system_mode.py    ← OS control gestures
│   ├── vscode_mode.py    ← VS Code gestures
│   └── sublime_mode.py   ← Sublime Text gestures
├── actions/
│   ├── volume.py         ← Audio control
│   ├── window.py         ← Window management
│   ├── screenshot.py     ← Screenshot capture
│   └── mouse.py          ← Mouse/keyboard
└── ui/
    └── overlay.py        ← Camera HUD
```

---

## Troubleshooting

**`ModuleNotFoundError: No module named 'cv2'`**
→ Run the setup script, or: `pip install opencv-python`

**Camera not opening**
→ Check `CAMERA_INDEX` in `config.py`. Try `1` or `2` if `0` doesn't work.

**Gestures not registering well**
→ Ensure good lighting. Adjust `MIN_DETECTION_CONF` in `config.py`.

**Volume/brightness not working on Linux**
→ Install missing tools: `sudo apt install pactl brightnessctl`

**Volume not working on Windows**
→ The setup script installs `pycaw`. If it fails, install [nircmd](https://www.nirsoft.net/utils/nircmd.html) and add it to PATH.

**Auto mode switch not working**
→ Install `xdotool` (Linux) or `pygetwindow` (Windows). Or run with `--no-auto`.
