# actions/volume.py
"""
Volume control — Linux (pactl/amixer) and Windows (pycaw / nircmd fallback).
"""
import sys
import subprocess

IS_WINDOWS = sys.platform.startswith("win")


# ── Linux helpers ──────────────────────────────────────────────

def _pactl(args):
    try:
        subprocess.run(["pactl"] + args,
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL,
                       timeout=2)
        return True
    except Exception:
        return False


def _amixer(args):
    try:
        subprocess.run(["amixer", "-q"] + args,
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL,
                       timeout=2)
        return True
    except Exception:
        return False


def _get_volume_linux():
    try:
        out = subprocess.check_output(
            ["pactl", "get-sink-volume", "@DEFAULT_SINK@"],
            stderr=subprocess.DEVNULL, timeout=2
        ).decode()
        for part in out.split():
            if part.endswith("%"):
                return int(part.rstrip("%"))
    except Exception:
        pass
    try:
        out = subprocess.check_output(
            ["amixer", "get", "Master"],
            stderr=subprocess.DEVNULL, timeout=2
        ).decode()
        import re
        m = re.search(r"\[(\d+)%\]", out)
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return None


# ── Windows helpers ────────────────────────────────────────────

def _get_windows_volume_iface():
    """Return a pycaw AudioEndpointVolume COM object, or None."""
    try:
        from ctypes import cast, POINTER
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        devices = AudioUtilities.GetSpeakers()
        iface   = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return cast(iface, POINTER(IAudioEndpointVolume))
    except Exception:
        return None


def _get_volume_windows():
    vol = _get_windows_volume_iface()
    if vol:
        try:
            return int(vol.GetMasterVolumeLevelScalar() * 100)
        except Exception:
            pass
    return None


def _set_volume_windows(pct):
    vol = _get_windows_volume_iface()
    if vol:
        try:
            vol.SetMasterVolumeLevelScalar(max(0.0, min(1.0, pct / 100)), None)
            return True
        except Exception:
            pass
    # nircmd fallback
    try:
        val = int(65535 * pct / 100)
        subprocess.run(["nircmd", "setsysvolume", str(val)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=2)
        return True
    except Exception:
        return False


# ── Public API ─────────────────────────────────────────────────

def get_volume():
    if IS_WINDOWS:
        return _get_volume_windows()
    return _get_volume_linux()


def volume_up(step=None):
    import config
    step = step or config.VOLUME_STEP
    if IS_WINDOWS:
        cur = _get_volume_windows() or 50
        _set_volume_windows(min(100, cur + step))
    else:
        if not _pactl(["set-sink-volume", "@DEFAULT_SINK@", f"+{step}%"]):
            _amixer(["set", "Master", f"{step}%+"])


def volume_down(step=None):
    import config
    step = step or config.VOLUME_STEP
    if IS_WINDOWS:
        cur = _get_volume_windows() or 50
        _set_volume_windows(max(0, cur - step))
    else:
        if not _pactl(["set-sink-volume", "@DEFAULT_SINK@", f"-{step}%"]):
            _amixer(["set", "Master", f"{step}%-"])


def volume_mute():
    if IS_WINDOWS:
        vol = _get_windows_volume_iface()
        if vol:
            try:
                muted = vol.GetMute()
                vol.SetMute(not muted, None)
                return
            except Exception:
                pass
        try:
            subprocess.run(["nircmd", "mutesysvolume", "2"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=2)
        except Exception:
            pass
    else:
        if not _pactl(["set-sink-mute", "@DEFAULT_SINK@", "toggle"]):
            _amixer(["set", "Master", "toggle"])


def media_playpause():
    if IS_WINDOWS:
        try:
            import pyautogui
            pyautogui.press("playpause")
        except Exception:
            pass
    else:
        try:
            subprocess.run(["playerctl", "play-pause"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=2)
        except Exception:
            try:
                import pyautogui
                pyautogui.press("playpause")
            except Exception:
                pass


def media_next():
    if IS_WINDOWS:
        try:
            import pyautogui
            pyautogui.press("nexttrack")
        except Exception:
            pass
    else:
        try:
            subprocess.run(["playerctl", "next"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=2)
        except Exception:
            pass


def media_prev():
    if IS_WINDOWS:
        try:
            import pyautogui
            pyautogui.press("prevtrack")
        except Exception:
            pass
    else:
        try:
            subprocess.run(["playerctl", "previous"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=2)
        except Exception:
            pass
