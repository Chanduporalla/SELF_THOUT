# actions/screenshot.py
"""
Screenshot capture — tries multiple backends for reliability.
"""
import sys
import os
import cv2

IS_WINDOWS = sys.platform.startswith("win")


def take_screenshot(filepath, mode="full", frame=None):
    """
    Save a screenshot to filepath.
    mode   : "full" = entire screen, "frame" = use the provided cv2 frame
    Returns (saved_path, backend_name) or (None, None) on failure.
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    # ── Frame capture (always available) ──────────────────────
    if mode == "frame" and frame is not None:
        try:
            cv2.imwrite(filepath, frame)
            return filepath, "frame"
        except Exception:
            pass

    # ── Full-screen capture ────────────────────────────────────
    # 1. pyautogui (cross-platform)
    try:
        import pyautogui
        img = pyautogui.screenshot()
        img.save(filepath)
        return filepath, "pyautogui"
    except Exception:
        pass

    # 2. scrot (Linux)
    if not IS_WINDOWS:
        try:
            import subprocess
            subprocess.run(["scrot", filepath],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL,
                           timeout=5)
            if os.path.exists(filepath):
                return filepath, "scrot"
        except Exception:
            pass

    # 3. Windows: PIL ImageGrab
    if IS_WINDOWS:
        try:
            from PIL import ImageGrab
            img = ImageGrab.grab()
            img.save(filepath)
            return filepath, "ImageGrab"
        except Exception:
            pass

    # 4. Last resort: save camera frame if available
    if frame is not None:
        try:
            cv2.imwrite(filepath, frame)
            return filepath, "frame-fallback"
        except Exception:
            pass

    return None, None
