# actions/mouse.py
"""
Mouse / keyboard actions — wraps pyautogui for cross-platform use.
"""
import pyautogui

pyautogui.FAILSAFE = False   # disable corner-of-screen exception
pyautogui.PAUSE    = 0.0     # no artificial delay between actions


def move(x, y):
    """Move mouse to absolute pixel position."""
    try:
        pyautogui.moveTo(x, y)
    except Exception:
        pass


def click(x=None, y=None, button="left"):
    try:
        if x is not None and y is not None:
            pyautogui.click(x, y, button=button)
        else:
            pyautogui.click(button=button)
    except Exception:
        pass


def right_click(x=None, y=None):
    click(x, y, button="right")


def double_click(x=None, y=None):
    try:
        if x is not None and y is not None:
            pyautogui.doubleClick(x, y)
        else:
            pyautogui.doubleClick()
    except Exception:
        pass


def scroll(amount):
    """Positive = scroll up, negative = scroll down."""
    try:
        pyautogui.scroll(amount)
    except Exception:
        pass


def press(key):
    try:
        pyautogui.press(key)
    except Exception:
        pass


def hotkey(*keys):
    try:
        pyautogui.hotkey(*keys)
    except Exception:
        pass


def drag_to(x, y, duration=0.2):
    try:
        pyautogui.dragTo(x, y, duration=duration, button="left")
    except Exception:
        pass
