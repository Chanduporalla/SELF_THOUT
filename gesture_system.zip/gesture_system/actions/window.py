# actions/window.py
"""
Window management — Linux (xdotool/wmctrl) and Windows (win32gui/pyautogui).
"""
import sys
import subprocess

IS_WINDOWS = sys.platform.startswith("win")


# ── Linux: xdotool wrapper ─────────────────────────────────────

def _xdo(*args):
    """Run xdotool with the given arguments. Silent on failure."""
    try:
        subprocess.run(["xdotool"] + list(args),
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL,
                       timeout=2)
        return True
    except Exception:
        return False


def _wmctrl(args):
    try:
        subprocess.run(["wmctrl"] + args,
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL,
                       timeout=2)
        return True
    except Exception:
        return False


# ── Shared pyautogui hotkey helper ─────────────────────────────

def _hotkey(*keys):
    try:
        import pyautogui
        pyautogui.hotkey(*keys)
        return True
    except Exception:
        return False


def _press(key):
    try:
        import pyautogui
        pyautogui.press(key)
        return True
    except Exception:
        return False


# ── Active window title ────────────────────────────────────────

def get_active_window_title():
    if IS_WINDOWS:
        try:
            import win32gui
            hwnd  = win32gui.GetForegroundWindow()
            return win32gui.GetWindowText(hwnd).lower()
        except Exception:
            pass
        try:
            import pygetwindow as gw
            wins = gw.getActiveWindow()
            return wins.title.lower() if wins else ""
        except Exception:
            return ""
    else:
        try:
            out = subprocess.check_output(
                ["xdotool", "getactivewindow", "getwindowname"],
                stderr=subprocess.DEVNULL, timeout=2
            ).decode().strip()
            return out.lower()
        except Exception:
            return ""


# ── Window actions ─────────────────────────────────────────────

def minimize_window():
    if IS_WINDOWS:
        _hotkey("win", "down")
    else:
        _xdo("getactivewindow", "windowminimize")


def maximize_window():
    if IS_WINDOWS:
        _hotkey("win", "up")
    else:
        _wmctrl(["-r", ":ACTIVE:", "-b", "add,maximized_vert,maximized_horz"])


def close_window():
    if IS_WINDOWS:
        _hotkey("alt", "F4")
    else:
        _xdo("getactivewindow", "windowclose")


def snap_left():
    if IS_WINDOWS:
        _hotkey("win", "left")
    else:
        _wmctrl(["-r", ":ACTIVE:", "-b", "remove,maximized_vert,maximized_horz"])
        try:
            import config
            subprocess.run(
                ["wmctrl", "-r", ":ACTIVE:", "-e",
                 f"0,0,0,{config.SCREEN_W // 2},{config.SCREEN_H}"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2
            )
        except Exception:
            pass


def snap_right():
    if IS_WINDOWS:
        _hotkey("win", "right")
    else:
        _wmctrl(["-r", ":ACTIVE:", "-b", "remove,maximized_vert,maximized_horz"])
        try:
            import config
            hw = config.SCREEN_W // 2
            subprocess.run(
                ["wmctrl", "-r", ":ACTIVE:", "-e",
                 f"0,{hw},0,{hw},{config.SCREEN_H}"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2
            )
        except Exception:
            pass


def lock_screen():
    if IS_WINDOWS:
        try:
            import ctypes
            ctypes.windll.user32.LockWorkStation()
        except Exception:
            _hotkey("win", "l")
    else:
        for cmd in [
            ["loginctl", "lock-session"],
            ["gnome-screensaver-command", "-l"],
            ["xdg-screensaver", "lock"],
            ["xscreensaver-command", "-lock"],
        ]:
            try:
                subprocess.run(cmd, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, timeout=2)
                return
            except Exception:
                continue
