# ui/overlay.py
"""
Draws the HUD overlay onto the camera frame.
"""
import cv2


# ── Colour palette (BGR) ──────────────────────────────────────
C_WHITE  = (255, 255, 255)
C_BLACK  = (0,   0,   0)
C_GREEN  = (50,  205,  50)
C_BLUE   = (255, 140,  0)    # orange-ish in BGR display
C_YELLOW = (0,   220, 220)
C_GRAY   = (160, 160, 160)
C_RED    = (50,   50, 220)


def _bar(frame, x, y, w, h, fill, label="", pct=None):
    """Draw a filled progress bar."""
    cv2.rectangle(frame, (x, y), (x + w, y + h), C_GRAY, 1)
    if pct is not None:
        filled = int(w * max(0, min(100, pct)) / 100)
        cv2.rectangle(frame, (x, y), (x + filled, y + h), fill, -1)
    if label:
        cv2.putText(frame, label, (x + 4, y + h - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, C_WHITE, 1, cv2.LINE_AA)


def draw(frame, gesture, mode_name, ctrl, fps, vol):
    """
    Annotate frame with gesture name, mode, FPS, volume, and log lines.
    Returns the annotated frame.
    """
    h, w = frame.shape[:2]

    # ── Semi-transparent top bar ──────────────────────────────
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (w, 44), C_BLACK, -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)

    # ── Mode badge ────────────────────────────────────────────
    mode_colours = {
        "system":  C_GREEN,
        "vscode":  C_BLUE,
        "sublime": C_YELLOW,
    }
    mc = mode_colours.get(mode_name, C_GRAY)
    badge = f" {mode_name.upper()} "
    (bw, bh), _ = cv2.getTextSize(badge, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    cv2.rectangle(frame, (8, 6), (8 + bw + 4, 6 + bh + 6), mc, -1)
    cv2.putText(frame, badge, (10, 6 + bh + 2),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, C_BLACK, 1, cv2.LINE_AA)

    # ── Gesture label ─────────────────────────────────────────
    g_label = gesture.replace("_", " ").upper() if gesture else "—"
    cv2.putText(frame, g_label, (w // 2 - 80, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, C_WHITE, 2, cv2.LINE_AA)

    # ── FPS ───────────────────────────────────────────────────
    cv2.putText(frame, f"FPS {fps:4.0f}", (w - 90, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, C_GRAY, 1, cv2.LINE_AA)

    # ── Volume bar ────────────────────────────────────────────
    if vol is not None:
        _bar(frame, 8, h - 22, 120, 14, C_GREEN,
             label=f"VOL {int(vol)}%", pct=vol)

    # ── Log lines ─────────────────────────────────────────────
    log = ctrl.get_log() if ctrl else []
    for i, line in enumerate(reversed(log[-5:])):
        y_pos = h - 40 - i * 18
        if y_pos < 50:
            break
        cv2.putText(frame, line, (8, y_pos),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.35, C_GRAY, 1, cv2.LINE_AA)

    return frame
