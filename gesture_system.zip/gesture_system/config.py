# config.py
# ══════════════════════════════════════════════════════════════
# Central configuration — edit this file to tune the system.
# ══════════════════════════════════════════════════════════════
import os
import sys

# ── Camera ────────────────────────────────────────────────────
CAMERA_INDEX  = 0
FRAME_W       = 1280
FRAME_H       = 720
CAMERA_FPS    = 60

# ── Detection ─────────────────────────────────────────────────
MAX_HANDS          = 1
MIN_DETECTION_CONF = 0.72
MIN_TRACKING_CONF  = 0.62
MODEL_COMPLEXITY   = 1

# ── Gesture feel ──────────────────────────────────────────────
# GESTURE_COOLDOWN  : seconds between discrete triggers    (0.4–1.0)
# CURSOR_SMOOTHING  : 0 = frozen, 1 = instant              (0.1–0.25)
# PINCH_THRESHOLD   : normalised pinch distance            (0.04–0.10)
# SCROLL_SENSITIVITY: scroll units per frame while held
GESTURE_COOLDOWN   = 0.65
CURSOR_SMOOTHING   = 0.18
PINCH_THRESHOLD    = 0.055
SCROLL_SENSITIVITY = 12

# ── System ────────────────────────────────────────────────────
VOLUME_STEP = 5   # percent per gesture

_home = os.path.expanduser("~")
SCREENSHOT_DIR = (
    os.path.join(_home, "Pictures", "gestures")
    if _home != "~"
    else os.path.join(os.getcwd(), "gesture_screenshots")
)

# ── Screen (auto-detected) ────────────────────────────────────
def _get_screen_size():
    try:
        import pyautogui
        return pyautogui.size()
    except Exception:
        return (1920, 1080)

SCREEN_W, SCREEN_H = _get_screen_size()

# ── Platform ──────────────────────────────────────────────────
IS_WINDOWS = sys.platform.startswith("win")
IS_LINUX   = sys.platform.startswith("linux")

# ── Modes ─────────────────────────────────────────────────────
DEFAULT_MODE = "system"   # "system" | "vscode" | "sublime"

# ── IDE auto-switch ───────────────────────────────────────────
AUTO_SWITCH_IDE_MODE  = True
VSCODE_WINDOW_TITLES  = ["visual studio code", "vscode", "code"]
SUBLIME_WINDOW_TITLES = ["sublime text", "sublime_text"]

# ── Validation ────────────────────────────────────────────────
def _validate():
    errors = []
    if not (0.0 < CURSOR_SMOOTHING <= 1.0):
        errors.append(f"CURSOR_SMOOTHING={CURSOR_SMOOTHING!r} must be in (0, 1]")
    if not (0.01 <= PINCH_THRESHOLD <= 0.5):
        errors.append(f"PINCH_THRESHOLD={PINCH_THRESHOLD!r} must be in [0.01, 0.5]")
    if not (0.05 <= GESTURE_COOLDOWN <= 5.0):
        errors.append(f"GESTURE_COOLDOWN={GESTURE_COOLDOWN!r} must be in [0.05, 5.0]")
    if SCROLL_SENSITIVITY <= 0:
        errors.append(f"SCROLL_SENSITIVITY={SCROLL_SENSITIVITY!r} must be > 0")
    if not (1 <= VOLUME_STEP <= 100):
        errors.append(f"VOLUME_STEP={VOLUME_STEP!r} must be in [1, 100]")
    if DEFAULT_MODE not in ("system", "vscode", "sublime"):
        errors.append(f"DEFAULT_MODE={DEFAULT_MODE!r} invalid")
    if errors:
        raise ValueError("config.py errors:\n" + "\n".join(f"  • {e}" for e in errors))

_validate()
