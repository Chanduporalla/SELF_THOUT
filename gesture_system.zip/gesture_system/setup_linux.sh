#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
#  Gesture System — Linux Setup
#  Usage:
#    cd gesture_system
#    bash setup_linux.sh
# ═══════════════════════════════════════════════════════════════

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}✔${NC}  $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $*"; }
fail() { echo -e "  ${RED}✖${NC}  $*"; }
info() { echo -e "  ${CYAN}→${NC}  $*"; }

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║   Hand Gesture Control — Linux Setup             ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── 1. Python version check ──────────────────────────────────
PYVER=$(python3 --version 2>&1 | awk '{print $2}')
PYMAJ=$(echo "$PYVER" | cut -d. -f1)
PYMIN=$(echo "$PYVER" | cut -d. -f2)
if [[ "$PYMAJ" -lt 3 || ( "$PYMAJ" -eq 3 && "$PYMIN" -lt 8 ) ]]; then
    fail "Python 3.8+ required. Found: $PYVER"
    exit 1
fi
ok "Python $PYVER"

# ── 2. Virtual environment ────────────────────────────────────
if [[ -n "$VIRTUAL_ENV" ]]; then
    ok "Virtualenv active: $VIRTUAL_ENV"
    PIP="pip"
else
    info "Creating virtualenv: venv/"
    python3 -m venv venv
    source venv/bin/activate
    ok "Virtualenv created and activated"
    PIP="pip"
fi

# ── 3. Python packages ────────────────────────────────────────
echo ""
info "Installing Python packages..."
$PIP install --upgrade pip --quiet
$PIP install -r requirements.txt 2>&1 | grep -E "(Successfully installed|already satisfied|ERROR)" || true

echo ""
echo "Import check:"
python3 -c "import cv2;       print('  ✔  cv2        ', cv2.__version__)"       || { fail "cv2 failed";       exit 1; }
python3 -c "import mediapipe; print('  ✔  mediapipe  ', mediapipe.__version__)" || { fail "mediapipe failed"; exit 1; }
python3 -c "import numpy;     print('  ✔  numpy      ', numpy.__version__)"     || { fail "numpy failed";     exit 1; }
python3 -c "import pyautogui; print('  ✔  pyautogui  ', pyautogui.__version__)" || warn "pyautogui needs display (OK if running on desktop)"

# ── 4. System tools ───────────────────────────────────────────
echo ""
info "Checking system tools..."
MISSING=()
declare -A TOOL_DESC=(
    [pactl]="Volume control"
    [playerctl]="Media control"
    [scrot]="Screenshots"
    [xdotool]="Key/window control"
    [wmctrl]="Window management"
    [brightnessctl]="Brightness control"
    [xclip]="Clipboard"
)
for tool in pactl playerctl scrot xdotool wmctrl brightnessctl xclip; do
    if command -v "$tool" &>/dev/null; then
        ok "$tool — ${TOOL_DESC[$tool]}"
    else
        fail "$tool — ${TOOL_DESC[$tool]}  [MISSING]"
        MISSING+=("$tool")
    fi
done

if [[ ${#MISSING[@]} -gt 0 ]]; then
    echo ""
    info "Installing missing tools via apt..."
    sudo apt-get update -qq
    sudo apt-get install -y "${MISSING[@]}" 2>&1 | grep -E "(installed|already|Unable)" || true
fi

# ── 5. Camera check ───────────────────────────────────────────
echo ""
info "Checking camera..."
if ls /dev/video* &>/dev/null; then
    ok "Camera device(s) found: $(ls /dev/video*)"
else
    warn "No /dev/video* devices found. Check CAMERA_INDEX in config.py."
fi

# ── 6. Screenshot dir ─────────────────────────────────────────
SSDIR="$HOME/Pictures/gestures"
mkdir -p "$SSDIR"
ok "Screenshot dir: $SSDIR"

# ── 7. Launch helper ──────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Setup complete!                                 ║"
echo "║                                                  ║"
echo "║  To run:                                         ║"
echo "║    source venv/bin/activate                      ║"
echo "║    python3 main.py                               ║"
echo "║                                                  ║"
echo "║  Optional flags:                                 ║"
echo "║    --mode vscode      start in VS Code mode      ║"
echo "║    --mode sublime     start in Sublime mode      ║"
echo "║    --no-auto          disable auto mode switch   ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
