@echo off
:: ═══════════════════════════════════════════════════════════════
::  Gesture System — Windows Setup
::  Double-click this file OR run from Command Prompt:
::    cd gesture_system
::    setup_windows.bat
:: ═══════════════════════════════════════════════════════════════

title Gesture System — Windows Setup
color 0A

echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║   Hand Gesture Control -- Windows Setup          ║
echo  ╚══════════════════════════════════════════════════╝
echo.

:: ── 1. Check Python ──────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python not found.
    echo  Download from https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo  [OK]  Python %PYVER%

:: ── 2. Virtual environment ────────────────────────────────────
if not exist "venv\" (
    echo  [->]  Creating virtualenv...
    python -m venv venv
)
call venv\Scripts\activate.bat
echo  [OK]  Virtualenv active

:: ── 3. Upgrade pip ───────────────────────────────────────────
echo  [->]  Upgrading pip...
python -m pip install --upgrade pip --quiet

:: ── 4. Python packages ────────────────────────────────────────
echo  [->]  Installing Python packages...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo  [ERROR] Package installation failed. Check your internet connection.
    pause
    exit /b 1
)

:: ── 5. Windows-specific extras ───────────────────────────────
echo  [->]  Installing Windows extras (pycaw, pywin32, pygetwindow)...
pip install pycaw pywin32 pygetwindow --quiet
if %errorlevel% neq 0 (
    echo  [WARN] Some Windows extras failed. Volume control may fall back to nircmd.
)

:: ── 6. Import check ───────────────────────────────────────────
echo.
echo  Import check:
python -c "import cv2; print('  [OK]  cv2        ' + cv2.__version__)"
python -c "import mediapipe; print('  [OK]  mediapipe  ' + mediapipe.__version__)"
python -c "import numpy; print('  [OK]  numpy      ' + numpy.__version__)"
python -c "import pyautogui; print('  [OK]  pyautogui  ' + pyautogui.__version__)"

:: ── 7. Screenshot dir ─────────────────────────────────────────
if not exist "%USERPROFILE%\Pictures\gestures\" (
    mkdir "%USERPROFILE%\Pictures\gestures"
)
echo  [OK]  Screenshot dir: %USERPROFILE%\Pictures\gestures

:: ── 8. Create run.bat launcher ───────────────────────────────
echo @echo off > run.bat
echo call venv\Scripts\activate.bat >> run.bat
echo python main.py %%* >> run.bat
echo  [OK]  Created run.bat launcher

echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║  Setup complete!                                 ║
echo  ║                                                  ║
echo  ║  To run, double-click run.bat  OR:               ║
echo  ║    call venv\Scripts\activate.bat                ║
echo  ║    python main.py                                ║
echo  ║                                                  ║
echo  ║  Optional flags:                                 ║
echo  ║    python main.py --mode vscode                  ║
echo  ║    python main.py --mode sublime                 ║
echo  ║    python main.py --no-auto                      ║
echo  ╚══════════════════════════════════════════════════╝
echo.
pause
