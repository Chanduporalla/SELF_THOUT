# core/detector.py
import cv2
import mediapipe as mp
import config


class HandDetector:
    def __init__(self):
        self._hands = None

    def start(self):
        self._hands = mp.solutions.hands.Hands(
            static_image_mode=False,
            max_num_hands=config.MAX_HANDS,
            min_detection_confidence=config.MIN_DETECTION_CONF,
            min_tracking_confidence=config.MIN_TRACKING_CONF,
            model_complexity=config.MODEL_COMPLEXITY,
        )
        self._draw  = mp.solutions.drawing_utils
        self._style = mp.solutions.drawing_styles
        return self

    def process_and_draw(self, frame, rgb):
        """
        Run hand detection on rgb, draw landmarks on frame.
        Returns (landmarks_list, annotated_frame).
        landmarks_list is a list of 21-point arrays (one per detected hand).
        """
        results = self._hands.process(rgb)
        landmarks = []
        if results.multi_hand_landmarks:
            for hlm in results.multi_hand_landmarks:
                self._draw.draw_landmarks(
                    frame, hlm,
                    mp.solutions.hands.HAND_CONNECTIONS,
                    self._style.get_default_hand_landmarks_style(),
                    self._style.get_default_hand_connections_style(),
                )
                landmarks.append(hlm.landmark)
        return landmarks, frame

    def close(self):
        if self._hands:
            self._hands.close()
            self._hands = None
