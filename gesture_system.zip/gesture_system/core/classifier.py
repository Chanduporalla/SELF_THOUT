# core/classifier.py
"""
Gesture classifier.

Returns (gesture_name: str, extra: dict) from a list of 21 MediaPipe landmarks.

Landmark indices (MediaPipe):
  0  WRIST
  4  THUMB_TIP       3  THUMB_IP
  8  INDEX_TIP       7  INDEX_DIP   6  INDEX_PIP   5  INDEX_MCP
  12 MIDDLE_TIP      11 MIDDLE_DIP  10 MIDDLE_PIP  9  MIDDLE_MCP
  16 RING_TIP        15 RING_DIP    14 RING_PIP    13 RING_MCP
  20 PINKY_TIP       19 PINKY_DIP   18 PINKY_PIP   17 PINKY_MCP
"""

import math
import config

# ── Helpers ────────────────────────────────────────────────────

def _dist(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)

def _tip_above_pip(lm, tip, pip):
    """Return True when fingertip is above (smaller y) its PIP joint."""
    return lm[tip].y < lm[pip].y

def _fingers_up(lm):
    """
    Return a 5-bool list [thumb, index, middle, ring, pinky].
    Thumb uses x-axis comparison (laterally extended).
    """
    thumb  = lm[4].x < lm[3].x   # works for right hand; flipped for left
    index  = _tip_above_pip(lm,  8,  6)
    middle = _tip_above_pip(lm, 12, 10)
    ring   = _tip_above_pip(lm, 16, 14)
    pinky  = _tip_above_pip(lm, 20, 18)
    return [thumb, index, middle, ring, pinky]

# ── Main classifier ────────────────────────────────────────────

def classify(lm, frame_w, frame_h):
    """
    lm        : list of 21 mediapipe landmark objects (normalised 0–1)
    frame_w/h : pixel dimensions (for cursor mapping)

    Returns (gesture: str, extra: dict)
    """
    up = _fingers_up(lm)
    pinch_dist = _dist(lm[4], lm[8])   # thumb tip ↔ index tip

    # ── Pinch (thumb + index close, others curled) ─────────────
    if pinch_dist < config.PINCH_THRESHOLD and not up[2]:
        return "pinch", {"x": lm[8].x, "y": lm[8].y}

    # ── Point / cursor move (index only) ──────────────────────
    if up[1] and not up[2] and not up[3] and not up[4]:
        cx = int(lm[8].x * frame_w)
        cy = int(lm[8].y * frame_h)
        return "point", {"cx": cx, "cy": cy,
                         "nx": lm[8].x, "ny": lm[8].y}

    # ── Peace / scroll (index + middle) ───────────────────────
    if up[1] and up[2] and not up[3] and not up[4]:
        # Use vertical position of index tip for scroll direction
        return "peace", {"ny": lm[8].y}

    # ── Open palm (all fingers up) ─────────────────────────────
    if all(up):
        return "open_palm", {}

    # ── Fist (all fingers down) ────────────────────────────────
    if not any(up):
        return "fist", {}

    # ── Thumbs up (thumb only) ─────────────────────────────────
    if up[0] and not up[1] and not up[2] and not up[3] and not up[4]:
        return "thumb_up", {}

    # ── Thumbs down ────────────────────────────────────────────
    if not up[0] and not up[1] and not up[2] and not up[3] and not up[4]:
        # distinguish fist vs thumbs-down by thumb tip y vs wrist y
        if lm[4].y > lm[0].y:
            return "thumb_down", {}

    # ── Three fingers (index + middle + ring) ─────────────────
    if up[1] and up[2] and up[3] and not up[4]:
        return "three", {}

    # ── Four fingers ──────────────────────────────────────────
    if up[1] and up[2] and up[3] and up[4] and not up[0]:
        return "four", {}

    # ── Pinky only ────────────────────────────────────────────
    if up[4] and not up[1] and not up[2] and not up[3]:
        return "pinky", {}

    return "unknown", {}
