# core/camera.py
import cv2
import config


class Camera:
    def __init__(self):
        self._cap = None

    def open(self):
        cap = cv2.VideoCapture(config.CAMERA_INDEX)
        if not cap.isOpened():
            raise RuntimeError(
                f"Cannot open camera index {config.CAMERA_INDEX}. "
                "Check CAMERA_INDEX in config.py."
            )
        cap.set(cv2.CAP_PROP_FRAME_WIDTH,  config.FRAME_W)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_H)
        cap.set(cv2.CAP_PROP_FPS,          config.CAMERA_FPS)
        self._cap = cap
        return self

    def read(self):
        if self._cap is None:
            return None, None
        ret, frame = self._cap.read()
        if not ret or frame is None:
            return None, None
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        return frame, rgb

    def release(self):
        if self._cap:
            self._cap.release()
            self._cap = None
